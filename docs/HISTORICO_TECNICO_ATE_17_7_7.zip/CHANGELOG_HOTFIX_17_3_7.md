# Hotfix 17.3.7 — Alíquotas básicas automáticas

- Corrige ALIQ_PIS e ALIQ_COFINS que apareciam como preenchimento manual na Correção Assistida.
- Usa o IND_INC_TRIB do registro 0110 para definir a alíquota básica do CST 01.
- Marca essas correções como automáticas seguras.
- Recalcula VL_PIS/VL_COFINS do C170 e os totais do C100 pai após aplicar.
- Não reapura o Bloco M automaticamente.
