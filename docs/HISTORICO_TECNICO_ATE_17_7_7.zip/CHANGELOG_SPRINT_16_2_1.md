# FiscalPro - Sprint 16.2.1

## Correção

- Inclui localmente as dependências usadas para gerar PDF:
  - ReportLab 4.5.1;
  - Pillow 12.3.0;
  - charset-normalizer 3.4.9.
- O FiscalPro não depende mais de instalar o pacote `reportlab` pela internet.
- Mantém a restauração automática caso qualquer teste falhe.
- Preserva a Sprint 16.1.3.1 e o recálculo dos totalizadores do SPED.

## Relatórios

- Consolidado ou separado por empresa;
- PDF e Excel;
- Subtotal por empresa e total geral;
- Próxima semana ou período personalizado;
- Inclusão opcional de contas vencidas.
