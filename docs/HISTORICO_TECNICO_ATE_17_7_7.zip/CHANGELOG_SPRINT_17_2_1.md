# FiscalPro — Sprint 17.2.1

## Integração da análise em lote com o motor estadual de Minas Gerais

- A análise em lote passa a chamar uma camada estadual específica quando o destino é MG.
- Calcula MVA ajustada para entradas interestaduais quando há MVA original, alíquota interestadual e alíquota interna de referência.
- Exibe MVA do documento, MVA original, MVA ajustada, MVA aplicada e o tipo utilizado.
- Identifica o adicional FEM/FCP de Minas Gerais de forma objetiva para o período de 01/01/2024 a 31/12/2026.
- Para autopeças como o NCM 85111000, confirma FCP/FEM igual a zero quando a mercadoria não integra a lista do Decreto nº 48.736/2023.
- Mantém separada a confirmação do enquadramento da ST e a responsabilidade pelo recolhimento.
- Quando a mercadoria está na tabela mineira, mas a UF de origem não integra o âmbito do acordo, confirma a incidência estadual e mantém a responsabilidade como revisão.
- Mostra a referência e a data de atualização da base oficial ST/MG instalada.
- Compara pMVAST e pFCPST do XML com os valores esperados quando esses campos estiverem presentes.
- Amplia a planilha Excel com os novos campos de MVA, FCP/FEM e vigência.
- XML e SPED originais continuam somente leitura.

## Segurança

O cálculo da MVA ajustada não transforma uma alíquota interna condicional em regra definitiva. Benefícios, regimes especiais e responsabilidade por recolhimento continuam marcados para revisão quando não puderem ser confirmados pelos dados do documento.

## Validação automatizada

- 11 testes específicos da Sprint 17.2.1.
- 42 testes de regressão das Sprints 17.0, 17.1 e 17.2.
- Total validado: 53 testes, sem falhas.
