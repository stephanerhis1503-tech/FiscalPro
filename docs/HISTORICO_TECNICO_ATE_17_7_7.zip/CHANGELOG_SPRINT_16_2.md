# FiscalPro - Sprint 16.2

## Relatório semanal de Contas a Pagar

- Novo botão **Relatório semanal** dentro do módulo Contas a Pagar.
- Período rápido **Próxima semana**, calculado de segunda-feira a domingo.
- Período personalizado com data inicial e final.
- Seleção de uma empresa específica ou das seis empresas do grupo.
- Opção **Consolidado**, gerando um único arquivo com resumo, subtotais e total geral.
- Opção **Separado**, gerando um arquivo por empresa com contas e um Resumo Geral.
- Exportação em PDF e Excel, podendo gerar os dois formatos na mesma operação.
- Opção de incluir contas vencidas anteriores ainda não pagas.
- Opção de relatório detalhado ou somente resumo.
- Relatórios consideram apenas contas sem data de pagamento.
- Empresas sem vencimentos continuam aparecendo no Resumo Geral com total zero.
- Arquivos separados são criados somente para empresas que possuem contas no período.
- Preservados o cadastro, a importação de Excel, a fila do robô e as correções de SPED.
