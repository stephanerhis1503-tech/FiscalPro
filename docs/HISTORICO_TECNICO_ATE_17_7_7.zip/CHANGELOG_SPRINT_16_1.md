# CHANGELOG — Sprint 16.1

## Contas a Pagar dentro do FiscalPro

- Nova aba **Contas a Pagar** na janela principal.
- Banco próprio em `dados/financeiro/contas_pagar.db`.
- Cadastro das seis empresas do Grupo Mega Motos.
- Cadastro, edição, exclusão, pagamento e reabertura de contas.
- Status calculado automaticamente: **A VENCER**, **VENCIDO** e **PAGO**.
- Filtros por empresa, competência, status e pesquisa textual.
- Resumo com total programado, pago, a vencer, vencido e próximos sete dias.
- Vínculo de PDF, XML, boleto, guia, comprovante ou outro arquivo à conta.
- Detecção conservadora de possíveis duplicidades.

## Planilha histórica

- Importação das abas das seis empresas.
- Compatibilidade com a planilha antiga e com a planilha preparada para o robô.
- Linhas vazias e totalizações antigas são ignoradas.
- Duplicidades não são importadas novamente.
- Exportação para Excel, separada por empresa.

## Integração com o Robô FiscalPro

- Nova **Fila financeira do Robô**.
- Documentos com valor ou vencimento entram na fila para conferência.
- Documentos incompletos ficam como **REVISAR**.
- Possíveis duplicidades ficam como **DUPLICADO**.
- A conta só é criada após a aprovação da usuária.
- O arquivo original permanece vinculado ao lançamento.

## Segurança e continuidade

- O banco financeiro passou a fazer parte dos backups do FiscalPro.
- Nenhum banco, token, senha, documento ou credencial está incluído no pacote da sprint.
- Funções do SPED 15.10 preservadas e retestadas.
