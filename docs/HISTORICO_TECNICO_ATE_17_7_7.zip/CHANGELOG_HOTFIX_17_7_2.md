# FiscalPro — Hotfix 17.7.2

## Cabeçalhos Oficiais SPED → Excel

### Correção
- O módulo **SPED TXT → Excel** deixa de exibir cabeçalhos genéricos como `CAMPO_01`, `CAMPO_02` etc. nos registros mapeados.
- A planilha passa a usar os **nomes técnicos dos campos do leiaute**, como `COD_ITEM`, `DESCR_ITEM`, `CST_PIS`, `VL_BC_PIS`, `ALIQ_PIS`, `VL_PIS`, `COD_CRED`, `NAT_BC_CRED`, entre outros.
- O exportador agora distingue explicitamente **EFD-Contribuições** de **EFD ICMS/IPI (Fiscal)** antes de escolher os cabeçalhos.

### Por que isso era necessário
Alguns registros possuem o mesmo código nas duas escriturações, mas não têm exatamente o mesmo leiaute. Exemplos:
- `0000`;
- `0200`;
- `C170`;
- `D100`.

Reutilizar um único cabeçalho podia gerar nomes genéricos ou, pior, um nome de campo pertencente ao outro tipo de SPED.

### EFD-Contribuições
Foram cadastrados os nomes técnicos dos registros usados pelo fluxo atual do FiscalPro, inclusive:
- Bloco 0: `0000`, `0110`, `0111`, `0140`, `0150`, `0190`, `0200`, `0400`, `0450`, `0500`;
- Bloco A: `A001`, `A010`, `A100`, `A170`, `A990`;
- Bloco C: `C001`, `C010`, `C100`, `C110`, `C170`, `C990`;
- Bloco D: `D001`, `D010`, `D100`, `D101`, `D105`, `D990`;
- Bloco F: `F001`, `F990`;
- Bloco M: `M001`, `M100`, `M105`, `M200`, `M210`, `M400`, `M410`, `M500`, `M505`, `M600`, `M610`, `M800`, `M810`, `M990`;
- Blocos 1 e 9 de fechamento.

### EFD ICMS/IPI
Os principais registros antes exibidos com títulos amigáveis também passam a usar os nomes técnicos oficiais, mantendo a estrutura e os contextos já aprovados.

### Segurança e reversibilidade
- O identificador oculto `__FP_ID__` e a aba técnica `_FISCALPRO_ORDEM` não foram alterados.
- O fluxo **Excel → SPED TXT** continua baseado na posição original dos campos, portanto a troca dos cabeçalhos não altera a reconstrução do TXT.
- Se surgir no futuro um campo novo ainda não cadastrado, o FiscalPro usa `POSICAO_XX_SEM_MAPEAMENTO` em vez de inventar um nome como se fosse oficial.
