# FiscalPro — Hotfix 17.3.15

## M105/M505 — correção pelo arquivo real

Corrige o bloqueio exibido ao executar **ICMS Fiscal → PIS/COFINS** no arquivo
`SPED CONT 07-2026 6.txt`.

### Causa identificada

O Bloco M possui quatro M105 e quatro M505 com CST 50 na mesma alíquota. A
versão anterior somava todos os C170 CST 50 para tentar identificar o filho do
Bloco M, misturando compras para revenda (CFOP 1102/2102) com outras entradas.
Além disso, o arquivo usa duas representações válidas que o motor tratava como
ambíguas: campo cumulativo vazio em M105/M505 e quantidade igual a zero em
M100/M500.

### Correções

- separa a base documental de compras para revenda CFOP 1102/2102 das demais
  entradas C170 para mapear o M105/M505 correto;
- aceita campo cumulativo vazio como zero quando toda a base é comprovadamente
  não cumulativa;
- aceita QUANT_BC igual a zero como ausência de crédito por quantidade;
- recalcula M105/M505, M100/M500 e M200/M600;
- sincroniza M205/M605 quando existe um único código de receita e ele espelhava
  exatamente o total anterior;
- mantém bloqueio se houver vários códigos de receita, ajustes ou qualquer
  necessidade de rateio não comprovado.

### Teste real

Com o arquivo `SPED CONT 07-2026 6.txt` e o SPED Fiscal de julho já corrigido:

- 15 notas cruzadas;
- 170 itens alterados;
- R$ 53.251,92 de ICMS próprio excluído das bases;
- redução de PIS: R$ 878,63;
- redução de COFINS: R$ 4.047,18;
- 28 alterações no Bloco M;
- Pré-Validador local: 0 erros e 0 avisos.

Testes automatizados do projeto: **39 aprovados**.
