# FiscalPro — Hotfix 17.7.1

## Guarda de Apuração do Bloco M antes do SPED → Excel

### Problema
Uma EFD Contribuições gerada diretamente no ERP pode ser aberta e exportada para Excel antes de o PGE executar **Gerar Apurações**. Quando isso acontece, os registros de crédito M100/M105 e M500/M505 podem não existir na base original. O problema só aparecia depois das alterações do Excel, durante a reconstrução do TXT.

### Correção
- nova validação automática ao abrir EFD Contribuições;
- detecta movimentos de crédito em A170/C170/D101/D105;
- bloqueia SPED → Excel quando há crédito de PIS sem M100/M105;
- bloqueia SPED → Excel quando há crédito de COFINS sem M500/M505;
- detecta M001 ausente ou marcado como bloco sem dados (IND_MOV=1) quando há movimento tributário;
- mantém arquivos sem crédito liberados quando a ausência de M100/M500 é legítima;
- SPED Fiscal não é afetado;
- o motor também repete a guarda antes da exportação, mesmo que a interface seja contornada.

### Orientação exibida
O FiscalPro orienta o fluxo seguro:

`ERP/Digisat → PGE → Gerar Apurações → validar/salvar → FiscalPro → Excel`

### Segurança
Nenhum registro do SPED é alterado por esta checagem. Ela apenas impede iniciar o Excel em uma base de EFD Contribuições que ainda não esteja pronta para o fluxo de ida e volta.
