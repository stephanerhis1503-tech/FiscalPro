# FiscalPro — Hotfix 17.6.4

## Sincronização automática C170 → C100 no Excel → SPED

- Ao validar uma planilha, alterações de PIS/COFINS em registros C170 agora identificam o C100 pai afetado.
- O FiscalPro soma `VL_PIS` e `VL_COFINS` dos C170 reconstruídos e sincroniza os totais `VL_PIS` e `VL_COFINS` do C100 correspondente.
- Apenas documentos afetados pelas alterações do Excel são retotalizados.
- O valor do C170 não é inventado ou recalculado nesta etapa: a rotina respeita o valor efetivamente informado/reconstruído a partir da planilha.
- Cada retotalização aparece na aba **Conferência Excel** como **Ajuste automático**, mostrando Original × Novo.
- O Excel original não é alterado.
- O Pré-PVA comparativo continua sendo executado depois da sincronização.

## Caso real validado durante o desenvolvimento

Planilha: `SPED CONT 07-2026_ORGANIZADO.xlsx`

- 4.229 alterações provenientes do Excel.
- Antes do hotfix: 42 novos erros no Pré-PVA, todos por divergência dos totais PIS/COFINS do C100 em relação aos C170.
- Depois do hotfix: 42 ajustes automáticos em 21 documentos C100.
- Novos erros introduzidos pela planilha após a sincronização: 0.

A validação oficial no PVA/PGE continua obrigatória antes da transmissão.
