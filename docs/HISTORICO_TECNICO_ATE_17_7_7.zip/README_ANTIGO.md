# FiscalPro

## Sprint 16.7 — Indicadores separados de ICMS próprio e ICMS-ST/MG

A Ficha Tributária agora mostra separadamente a segurança da alíquota do ICMS próprio e a segurança do enquadramento no ICMS-ST de Minas Gerais. Assim, uma alíquota residual condicional não reduz nem confunde um CEST/MVA confirmado.

ssistente Fiscal Inteligente

## Sprint 16.6 — Motor ICMS/MG, ICMS-ST e benefícios

A Consulta Tributária ganhou o botão **Base ICMS/MG**. O motor separa a alíquota nominal, o enquadramento no ICMS-ST, os benefícios reconhecidos e as pendências que ainda exigem conferência. A regra interna residual de 18% é apenas condicional e não sobrescreve o cadastro; regras objetivas podem ser confirmadas com fundamento e fonte.

A cobertura offline preserva os segmentos já validados. O botão **Atualizar cobertura ST/MG** amplia a leitura da Parte 2 do Anexo VII para capítulos com CEST, NCM, descrição, âmbito e MVA numérica. PMPF, preço fixado, pauta e hipóteses sem MVA estruturada permanecem em revisão. A ausência de um NCM na cobertura não confirma ausência de substituição tributária.

## Sprint 16.5 — Motor Nacional de PIS/COFINS (etapa segura)

A Consulta Tributária ganhou o botão **Base PIS/COFINS**. O novo motor confirma automaticamente somente situações com regra objetiva já estruturada, como revenda monofásica de autopeças/pneus e exportação explicitamente informada. Para operações comuns, apresenta a alíquota-padrão do regime como **sugestão condicional**, sem gravá-la como tributação confirmada.

O FiscalPro agora separa claramente: tributação confirmada, sugestão por regime, divergência com cadastro existente e revisão necessária. As Tabelas 4.3.10 a 4.3.16 da EFD-Contribuições ficam catalogadas como fontes estruturantes. Esta etapa ainda não importa todas as linhas de produtos com alíquota zero, suspensão, isenção e regimes setoriais; essas relações entram gradualmente nas próximas sprints.

## Robô Fiscal — Sprint 2.5: Leitura e Conferência Inteligente

O robô agora lê dados estruturados de NF-e e CT-e e tenta extrair de PDFs pesquisáveis o tipo da guia, CNPJ, competência, valor, vencimento e número do documento. A leitura é conservadora: PDFs digitalizados, dados ausentes ou divergência de CNPJ permanecem marcados para revisão.

Em **Painel mensal > Documentos esperados**, informe o CNPJ de cada empresa. Depois, em **Ver documentos salvos**, use **Analisar documentos** para conferir arquivos já registrados. A tabela mostra o resumo da leitura e permite abrir **Ver conferência** para consultar os alertas. Vencimento passado significa apenas que a data já ocorreu; o FiscalPro orienta conferir se a guia foi paga ou atualizada.

Antes do primeiro uso desta sprint, execute `INSTALAR_ROBO_EMAIL.bat` para instalar o leitor de PDF `pypdf`.

## Robô Fiscal — Sprint 2.4: Organização Automática

Todo documento novo recebido pelo Gmail, baixado por link autorizado ou importado pelo fluxo assistido passa por um único organizador. O robô verifica duplicidade antes de gravar, identifica a competência, cria um nome claro e salva em `Empresa > Ano > Mês > Tipo`. XMLs de NF-e e CT-e usam a data de emissão e recebem número/chave no nome quando disponíveis.

Quando a empresa não puder ser identificada, o arquivo é enviado para `_Revisar`, sem ser misturado com os documentos das seis empresas. No **Painel mensal**, o botão **Ver documentos salvos** apresenta o nome original, o nome organizado e o caminho completo, com atalhos para abrir o arquivo ou sua pasta. Arquivos antigos continuam preservados e visíveis; a nova nomenclatura é aplicada aos documentos processados a partir desta sprint.

## Sprint 14.4 — MVA ajustada e cálculo de ICMS-ST/MG

A Ficha Inteligente ganhou a opção **Mais opções > Calcular ICMS-ST** para produtos já enquadrados na tabela oficial de Minas Gerais. A janela preenche a MVA original oficial, calcula a MVA ajustada quando cabível e mostra toda a memória: valor dos produtos + IPI, base de partida, base do ICMS-ST, ICMS presumido, ICMS próprio a deduzir, ICMS-ST e FCP-ST.

A rotina é assistida: alíquota interna, ICMS próprio, FCP e situações especiais precisam ser conferidos. PMPF, preço tabelado, redução de base, benefício e regime especial não são tratados pela regra geral desta sprint.

## Sprint 14.3 — ICMS-ST/MG para autopeças

A Ficha Inteligente pode sincronizar diretamente da SEF/MG o Capítulo 1 da Parte 2 do Anexo VII do RICMS/MG. Para os NCMs de autopeças localizados, mostra CEST, descrição legal, âmbito e MVA original.

A confirmação é conservadora: operações internas de Minas Gerais são diferenciadas das interestaduais; quando a UF de origem não está abrangida pelo âmbito indicado, o produto permanece enquadrado na tabela mineira, mas a responsabilidade pelo recolhimento fica marcada para revisão. A alíquota própria de ICMS ainda não é confirmada automaticamente nesta sprint.

## Sprint 14.1 — Consulta Oficial Simplificada

A Ficha Inteligente agora separa o cadastro operacional das confirmações oficiais. A tabela NCM vigente e a TIPI podem ser sincronizadas diretamente das fontes oficiais; ICMS, ICMS-ST, PIS e COFINS permanecem sinalizados para revisão enquanto não houver base legal específica vinculada.

A tela principal mantém poucos comandos: **Analisar tributação**, **Ver base legal**, **Salvar ficha** e **Mais opções**.

## Robô Fiscal — Sprint 2.2: Painel Mensal de Documentos

A aba **Robô Fiscal** agora possui o botão **Painel mensal**, com acompanhamento das seis empresas por mês e ano.

O painel mostra e-mails processados, XMLs, guias, PDFs, ZIPs, outros documentos, links pendentes, duplicidades, erros e a data do último processamento. A situação de cada empresa aparece como **Recebido**, **Recebido — sem guias**, **Revisar pendências** ou **Sem documentos**.

Também é possível abrir a pasta mensal da empresa, processar o Gmail, acessar os links pendentes e exportar o relatório em CSV compatível com Excel.

## Sprint 13.7 — Ficha Inteligente Simplificada

Fluxo principal: **pesquisar produto → escolher operação → analisar → salvar, gerar parecer ou comparar com o SPED**.

A tela principal mostra somente os tributos essenciais. O cadastro completo de regras, legislação, IBS/CBS e histórico continua disponível no botão **Ver detalhes tributários**.

## Robô Fiscal — Gmail

A aba **Robô Fiscal** conecta o FiscalPro à conta `grupomegamotos.fiscal@gmail.com` por OAuth e opera em modo somente leitura.

### Sprint 2 — Links Seguros e Guias

Além dos anexos, o robô identifica links de documentos fiscais, registra domínios desconhecidos como pendentes e permite download somente após autorização. Downloads automáticos ficam desativados por padrão e aceitam apenas HTTPS com arquivos PDF, ZIP ou XML validados.

Consulte `CONFIGURAR_GMAIL_ROBO.txt` antes de autorizar o domínio do portal da contabilidade.
