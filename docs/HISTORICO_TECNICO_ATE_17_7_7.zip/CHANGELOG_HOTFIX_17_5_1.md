# FiscalPro — Hotfix 17.5.1

## Integração ICMS próprio × ICMS-ST

### Problema corrigido
Na Sprint 17.5.0 o Robô Tributário conseguia confirmar que um produto estava sujeito ao ICMS-ST, mas ainda apresentava a análise da alíquota do ICMS próprio de forma isolada. Em operações de saída subsequente isso podia sugerir, de forma ambígua, um novo débito de ICMS mesmo quando o imposto já havia sido retido anteriormente por substituição tributária.

### O que mudou
- O Robô Tributário agora distingue **produto sujeito ao ICMS-ST** de **responsabilidade por retenção nesta operação**.
- Novo campo **Situação ICMS-ST** no contexto da operação:
  - Não informado;
  - ICMS-ST já retido na entrada;
  - Responsável por reter ICMS-ST nesta saída;
  - Mercadoria sem retenção de ICMS-ST.
- Novo campo **Perfil remetente** na tela do Robô Tributário.
- Em venda interna MG → MG, quando o usuário informa que o ICMS-ST já foi retido na entrada:
  - ICMS: saída sem destaque;
  - CST 060 para regime normal;
  - CSOSN 500 para Simples Nacional;
  - a alíquota nominal deixa de ser apresentada como débito da saída;
  - o CEST e a MVA permanecem como referência do enquadramento do produto;
  - o robô informa que não há nova retenção de ST nessa saída.
- Se o produto estiver sujeito à ST e a situação da retenção não for informada, o robô marca **REVISAR** em vez de presumir a responsabilidade.
- Se a operação for marcada como “sem retenção” para produto confirmado na ST, o robô exige revisão de exceção/dispensa.
- A regra automática de CST 060/CSOSN 500 foi limitada a venda interna em MG e ao contexto explícito “ICMS-ST já retido na entrada”.

### Base legal usada no hotfix
RICMS/MG/2023, Anexo VII, Parte 1, art. 27: o contribuinte que recebe mercadoria com imposto retido por substituição tributária emite a saída sem destaque do imposto, utilizando CST 060 ou CSOSN 500, conforme o regime.

### Segurança
O hotfix continua assistivo. Não grava regra tributária e não altera documento fiscal automaticamente.

### Testes
- 69 testes automatizados aprovados.
- Teste integrado com NCM 4011.40.00, pneu de motocicleta, MG → MG, Lucro Real, venda, ICMS-ST já retido na entrada:
  - PIS/COFINS: CONFIRMADO;
  - ICMS: CONFIRMADO — sem destaque — CST 060;
  - ICMS-ST: CONFIRMADO — CEST 16.003.00 — MVA 60% — sem nova retenção;
  - Reforma 2026: permanece REVISAR por ser cenário padrão, sem enquadramento específico.
