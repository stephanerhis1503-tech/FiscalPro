# FiscalPro — Sprint 15.9

## DANFE/PDF × SPED — ICMS das compras para revenda

- Leitura de DANFEs digitais em PDF, PDFs individuais, pastas ou arquivos ZIP.
- Conferência da chave da NF-e, CNPJ do destinatário, C100, itens C170 e totais do ICMS.
- Aplicação restrita a entradas de terceiros escrituradas integralmente como compra para revenda, CFOP 1102 ou 2102.
- Preenchimento de CST, base de cálculo, alíquota e valor do ICMS nos registros C170.
- Reconstrução segura do C190, preservando o valor da operação e consolidando por CST, CFOP e alíquota.
- Geração de nova cópia do SPED sem BOM, memória CSV e relatório detalhado.
- Integração direta com o módulo de estorno: a nova cópia pode ser aberta e analisada para geração de C195/C197.
- PDFs sem ICMS próprio, notas divergentes ou documentos não encontrados permanecem sem alteração e são apresentados para revisão.
- Versão da aplicação e do instalador atualizada para 15.9.
