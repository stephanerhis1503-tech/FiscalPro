# FiscalPro — Hotfix 17.6.5

## Bloco M integrado ao fluxo Excel → SPED TXT

### Problema
O FiscalPro já corrigia/reapurava o Bloco M nos fluxos de correção do TXT, mas o fluxo
SPED → Excel → SPED TXT reconstruía os documentos sem reaplicar toda essa camada.
Assim, alterações tributárias feitas no Excel podiam deixar M100/M105/M500/M505 e
as totalizações do Bloco M inconsistentes no PGE.

### Correções
- reaplica a sincronização segura do Bloco M durante a validação Excel → TXT;
- consolida automaticamente grupos seguros de M100/M500 duplicados, preservando M105/M505;
- aceita deltas de crédito positivos e negativos causados por reclassificações de CST no C170;
- sincroniza M105/M505 e recalcula M100/M500 e M200/M600 quando o vínculo é comprovável;
- reaplica a sincronização de débitos M210/M200 e M610/M600 já existente;
- retotaliza M400/M410 e M800/M810 quando a receita sem incidência pode ser comprovada
  exclusivamente pelos documentos A170/C170 e existe um único filho que espelhava o pai;
- preserva NAT_REC: o FiscalPro não inventa natureza de receita;
- recalcula M990, 9900, 9990 e 9999 quando o Bloco M altera a estrutura;
- mostra os ajustes automáticos do Bloco M na Conferência Excel e no relatório.

### Teste com os arquivos MEGA T.O. — 07/2026
- 4.229 campos alterados no Excel;
- 42 totais C100 sincronizados em 21 documentos;
- 2 grupos seguros M100/M500 consolidados;
- 82 ajustes/totalizações automáticas do Bloco M;
- Pré-PVA local: 149 erros no arquivo original → 5 no reconstruído;
- novos erros criados pelo Excel: 0;
- M400/M800: 417.282,83 → 417.673,45;
- base consolidada M100 1,65%: 487.741,99;
- base consolidada M500 7,60%: 487.741,99.

### Segurança
- nenhum NAT_REC é inventado;
- aumento/redução de crédito só é aplicado quando o M105/M505 correspondente é identificado
  pelas regras seguras já aprovadas nas séries 17.3.12–17.3.16;
- vínculos ambíguos continuam bloqueando a geração;
- o PVA/PGE oficial continua sendo a validação final.

### Testes automatizados
- 108 testes aprovados.
