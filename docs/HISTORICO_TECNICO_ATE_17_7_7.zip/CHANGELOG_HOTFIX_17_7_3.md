# FiscalPro — Hotfix 17.7.3

## Edição Manual Assistida do Bloco M

### Problema corrigido
Ao corrigir a EFD-Contribuições diretamente na planilha, apagar conscientemente
um M100, M105, M500 ou M505 fazia o FiscalPro bloquear a geração com a mensagem
"A linha original não foi encontrada". Isso confundia uma correção intencional
com perda acidental da estrutura técnica.

### Novo comportamento
- Exclusões manuais dos registros suportados do Bloco M são respeitadas.
- Alterações manuais de alíquota/base do Bloco M passam a ativar o **Modo Manual do Bloco M**.
- Nesse modo o FiscalPro **não recria registro apagado**, **não reclassifica crédito** e
  **não sobrescreve COD_CRED, NAT_BC_CRED ou CST**.
- O automático de C170 → M100/M105/M500/M505 fica suspenso quando a usuária já
  assumiu a correção manual do Bloco M.
- Para grupos simples, o FiscalPro ajuda recalculando apenas a aritmética
  determinística: base do pai, valor do crédito, crédito disponível/descontado e,
  quando a rotina conservadora consegue provar, M200/M600.
- O M990 e os totalizadores 0990/9900/9990/9999 são recalculados depois de exclusões.
- Toda exclusão manual aparece na **Conferência Excel**.

### Registros do Bloco M liberados para exclusão manual
`M100`, `M105`, `M200`, `M210`, `M400`, `M410`, `M500`, `M505`, `M600`,
`M610`, `M800` e `M810`.

`M001` e `M990` continuam protegidos como abertura/fechamento estrutural do bloco.

### Segurança
O modo manual não inventa grupo de crédito nem natureza. Se um grupo tiver
crédito por quantidade, ajustes, diferimento, base cumulativa ou bases
inconsistentes, a aritmética é preservada como digitada e o FiscalPro emite
aviso para conferência no PGE.

O PGE continua sendo a validação oficial antes da transmissão.
