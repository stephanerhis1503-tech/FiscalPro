# FiscalPro — Sprint 16.7.0

## Indicadores independentes de ICMS/MG

- Separa a segurança do **ICMS próprio/MG** da segurança do **ICMS-ST/MG**.
- Um enquadramento de ICMS-ST confirmado não é mais apresentado junto da alíquota residual condicional.
- Exibe CEST, MVA, segmento e aplicação da operação na observação específica do ICMS-ST.
- Mantém a segurança geral do parecer como indicador independente.
- Preserva compatibilidade com integrações que ainda chamam o indicador antigo `icms_mg`.
- Atualiza a versão central do FiscalPro para **16.7.0**.

## Exemplo esperado

Para o NCM 85111000 em operação interna de Minas Gerais:

- Segurança ICMS próprio/MG: **70% — CONDICIONAL**;
- Segurança ICMS-ST/MG: **100% — CONFIRMADA**;
- CEST: **01.054.00**;
- MVA original: **71,78%**.

Nenhuma regra tributária ou cálculo foi alterado nesta Sprint. A mudança é de
clareza, rastreabilidade e segurança da apresentação dos resultados.
