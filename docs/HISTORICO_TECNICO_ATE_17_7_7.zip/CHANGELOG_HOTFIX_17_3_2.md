# Hotfix 17.3.2 — Cadastro contínuo no Contas a Pagar

## Alteração

- Ao salvar uma conta nova cadastrada manualmente, a janela permanece aberta.
- O formulário é limpo e fica pronto para o próximo lançamento.
- A empresa e a competência são preservadas para agilizar lançamentos em sequência.
- Fornecedor, valor, vencimento, descrição, documento, arquivo, pagamento e observações são limpos.
- A categoria volta para `OUTROS`, reduzindo o risco de repetir uma categoria incorreta.
- Uma mensagem de sucesso é mostrada dentro da própria janela, sem interromper o trabalho.
- Edição de conta existente e aprovação da fila do Robô continuam fechando a janela após salvar.

## Segurança

- Nenhuma conta existente, banco de dados ou regra tributária foi alterada.
- O fornecedor recém-utilizado continua gravado e disponível na busca automática.
