from src.inteligencia.motor_tributario import MotorTributario
from src.inteligencia.consulta_tributaria import ConsultaTributaria


def consultar(ncm):
    consulta = ConsultaTributaria(
        ncm=ncm,
        uf_origem="MG",
        uf_destino="MG",
        regime="Lucro Real",
        operacao="Venda",
        consumidor_final=True,
    )
    return MotorTributario().consultar(consulta)


for codigo in ("85122011", "39269090", "87141000"):
    ficha = consultar(codigo)
    assert ficha is not None, f"NCM {codigo} não retornou ficha"
    assert ficha.status == "BASE_DIGISAT", ficha.status
    assert ficha.quantidade_produtos > 0
    print(
        codigo,
        ficha.cfop,
        ficha.cst_icms,
        ficha.icms_st,
        ficha.pis_cst,
        ficha.aliquota_pis,
        ficha.cofins_cst,
        ficha.aliquota_cofins,
    )

print("SPRINT 9 OK")
