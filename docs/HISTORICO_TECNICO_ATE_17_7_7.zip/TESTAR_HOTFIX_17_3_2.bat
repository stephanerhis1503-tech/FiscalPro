@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ===============================================
echo FiscalPro - Teste do Hotfix 17.3.2
echo Cadastro continuo no Contas a Pagar
echo ===============================================
echo.
python TESTE_HOTFIX_17_3_2.py
if errorlevel 1 (
    echo.
    echo TESTE COM ERRO. Revise a mensagem acima.
    pause
    exit /b 1
)
echo.
echo TESTE CONCLUIDO COM SUCESSO.
pause
