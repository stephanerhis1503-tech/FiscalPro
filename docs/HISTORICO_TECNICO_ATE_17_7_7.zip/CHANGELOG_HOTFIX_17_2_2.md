# FiscalPro — Hotfix 17.2.2

## Correção da observação de FCP/FEM

- Remove da análise em lote a mensagem antiga de que o FCP/MG ainda não estava automatizado.
- Exibe a conclusão produzida pelo motor estadual integrado de Minas Gerais.
- Para mercadoria fora da lista objetiva do FEM/MG, mostra `0,00% — não aplicável à mercadoria consultada`.
- Para mercadoria alcançada, mostra a alíquota confirmada pelo motor estadual.
- Para regra fora da vigência ou não confirmada, mantém a indicação de revisão.
- Não altera MVA, ICMS-ST, FCP/FEM, divergências, pendências, XML ou SPED.

## Validação

- 7 testes específicos do Hotfix 17.2.2.
- Regressão funcional da integração estadual de MG preservada.
