## Hotfix 17.3.6 — Marcação em lote da Correção Assistida (07/08/2026)

- Adicionado botão **☑ Marcar todas aplicáveis** na aba Correção assistida.
- Um único clique marca todas as propostas que já possuem valor sugerido e podem ser gravadas.
- Antes da marcação, o FiscalPro mostra quantas são automáticas seguras e quantas são sugestões calculadas.
- Itens sem valor sugerido, preenchimentos pendentes e ocorrências somente para revisão permanecem desmarcados.
- Mantida a proteção: o arquivo original nunca é alterado; a aplicação continua gerando uma nova cópia.
- Preservado o botão **✅ Marcar seguras** para quem quiser aplicar somente as correções de alta segurança.
