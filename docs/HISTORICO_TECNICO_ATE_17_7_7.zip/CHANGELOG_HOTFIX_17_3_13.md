# FiscalPro — Hotfix 17.3.13

## Mapeamento robusto M105/M505 na exclusão do ICMS

Corrige o bloqueio:

> "O M105 correspondente aos C170 de alíquota ... / CST 50 não pôde ser identificado com segurança."

### O que mudou

- Mantém a comparação direta por base como primeira regra.
- Quando houver vários M105/M505 na mesma alíquota/CST, usa a composição documental do próprio SPED:
  - A170;
  - C170;
  - D101/D105.
- Identifica primeiro os filhos que fecham com A170 e D101/D105 e, quando a composição global fecha dentro da tolerância segura, associa o filho remanescente ao C170.
- Não altera NAT_BC_CRED, não reclassifica crédito e não escolhe um M105/M505 por aproximação cega.
- Se a composição não fechar, o FiscalPro continua bloqueando a geração em vez de inventar a apuração.

### Regressão

- 34 testes automatizados aprovados.
- Mantidas as regras do Hotfix 17.3.12 para cruzamento por chave + item + código, exclusão única do ICMS, recálculo de C170/C100 e sincronização do Bloco M.
