# FiscalPro — Sprint 15.7

## Estorno assistido dos créditos de ICMS no SPED

### Implementado

- Nova aba **Estorno ICMS** dentro do SPED Inteligente.
- Botão visível **Estorno créditos ICMS**.
- Leitura das NF-e de entrada (`C100`) e dos créditos por item (`C170`).
- Preparação automática dos registros `C195` e `C197`, sem zerar ou alterar `C170` e `C190`.
- Agrupamento seguro de itens repetidos na mesma nota, código e alíquota.
- Detecção de estornos já existentes para impedir duplicidade.
- Atualização do total dos ajustes a débito no `E110` e recálculo dos totalizadores do arquivo.
- Geração de três arquivos:
  - nova cópia do SPED com estorno;
  - memória de cálculo em CSV;
  - relatório de conferência em TXT.
- Detecção do número do regime especial em `C110` quando informado.
- Escolha explícita do código de ajuste C197 antes da geração.
- Alerta especial para o código `MG50000018`, que aparece no SPED-modelo, mas possui descrição oficial vigente diferente do TTS.
- Preservação integral do arquivo original.

### Modelo analisado

O SPED de junho/2026 da MEGA T.O. E-COMMERCE foi usado como modelo estrutural. Nele, o estorno é escriturado por item com `C195/C197`, e o total dos ajustes corresponde aos créditos das entradas.

### Segurança

- Itens sem detalhamento suficiente permanecem como **REVISAR**.
- O FiscalPro não escolhe silenciosamente o código legal.
- A nova cópia deve ser validada no PVA antes da entrega.
- Nenhum banco de dados ou documento pessoal integra esta sprint.
