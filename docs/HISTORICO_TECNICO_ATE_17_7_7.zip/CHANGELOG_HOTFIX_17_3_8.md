# Hotfix 17.3.8 — CST em Lote + Reapuração Segura do Bloco M

## Correções

- O CST de PIS/COFINS `08` em C170 de entrada (CFOP 1xxx, 2xxx ou 3xxx) deixa de aparecer como **Preencher manualmente**.
- Nesses casos, o FiscalPro sugere e marca automaticamente `74` (**aquisição sem incidência**), preservando bases e valores zerados.
- A correção pode ser aplicada em lote pelo botão **Marcar todas aplicáveis**; não é necessário confirmar item por item.
- Após alterações determinísticas de CST/alíquotas em C170, o FiscalPro sincroniza a parcela segura da apuração do Bloco M:
  - atualiza `M210` e `M200` pelo delta de PIS;
  - atualiza `M610` e `M600` pelo delta de COFINS quando já existirem;
  - quando `M600/M610` estiverem ausentes, cria esses registros somente sob guardas conservadoras: uma única apuração básica, bases PIS/COFINS pareadas e ausência de deduções especiais no M200.
- `M100/M105/M500/M505` são preservados quando a correção não altera direito a crédito.
- Se o Bloco M mudar, `M990`, `9900`, `9990` e `9999` são recontados automaticamente na mesma geração.

## Validação no arquivo real MEGA MIX 07/2026

- Pré-validação inicial: **159 causas raiz / 277 ocorrências estimadas no PGE / 3 avisos**.
- Correções seguras preparadas: **148**.
- Aplicação real do Hotfix 17.3.8: **255 alterações rastreadas**, incluindo dependências e Bloco M.
- Pré-validação após a cópia corrigida: **11 causas raiz / 27 ocorrências estimadas / 3 avisos**.
- Pendências restantes são deliberadamente não automáticas: duplicidades de COD_ITEM, CFOP 1929 e duplicidades de chaves de crédito M100/M500.

## Testes

- 16 testes automatizados aprovados, incluindo regressões das versões 17.3.4, 17.3.6 e 17.3.7.
