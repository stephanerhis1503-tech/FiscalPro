# FiscalPro — Sprint 17.2.0

## Análise tributária em lote de XML, ZIP e SPED

- Criado o serviço `AnaliseTributariaLoteService` para analisar diversos documentos sem alterar os arquivos originais.
- Fontes aceitas:
  - NF-e XML;
  - arquivos ZIP contendo XML ou SPED TXT;
  - pastas com documentos;
  - SPED Fiscal ou Contribuições com itens C170.
- O lote cruza cada item com as bases e motores já aprovados de:
  - NCM oficial e descrição nacional;
  - TIPI/IPI como referência;
  - PIS e Cofins, incluindo monofásico;
  - ICMS próprio por UF;
  - ICMS-ST, CEST, MVA original e MVA ajustada;
  - FCP/FECOP e vigência da regra estadual.
- Divergências confirmadas ficam separadas das regras condicionais e das pendências de revisão.
- Para o SPED, o FiscalPro utiliza os registros 0200, 0150, C100 e C170 para recuperar produto, participante, documento, UFs e tributação atual.
- Para a NF-e, o FiscalPro utiliza as UFs e a data do próprio XML quando essa opção está marcada.
- Criada a nova tela **Análise em lote** na aba Tributação, com:
  - seleção múltipla de XML, ZIP e SPED;
  - importação de pasta;
  - filtros por confirmado, divergência, revisão e ausência de NCM;
  - detalhes com fundamento e fontes por item;
  - processamento fora da interface para evitar travamento da janela.
- Criado exportador Excel com as abas `Resumo`, `Itens`, `Divergências` e `Fontes`.
- Adicionados limites de segurança para quantidade e tamanho dos arquivos compactados.
- Atualizados aplicativo, executável e instalador para a versão 17.2.0.
- Adicionados 10 testes automatizados da Sprint e ajustados os testes de regressão das Sprints 17.0 e 17.1 para versões posteriores.

## Limites desta fase

- A análise do SPED cobre itens de mercadorias do registro C170. Registros de serviços, como A170 e F100, ainda não entram no lote.
- A TIPI é apresentada como referência e não confirma, sozinha, a incidência de IPI na operação concreta.
- Benefícios, reduções, isenções, diferimentos e regimes especiais que ainda não estejam automatizados permanecem marcados para revisão.
- A Sprint somente analisa e exporta; ela não corrige XML nem SPED automaticamente.
