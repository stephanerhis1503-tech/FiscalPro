# FiscalPro — Hotfix 17.6.6

## Ordem hierárquica M600/M610 no Excel → SPED TXT

### Problema encontrado no PGE
Ao criar automaticamente M600/M610 em um arquivo que já possuía M800/M810, o Hotfix 17.6.5 inseria a apuração da COFINS imediatamente antes do M990. Isso deixava a sequência:

`M800 → M810 → M600 → M610 → M990`

O PGE rejeitava M600 e M610 porque, nessa hierarquia, eles devem aparecer antes de M800/M810. Como consequência, também surgiam erros em QTD_LIN_M (M990) e QTD_LIN (9999).

### Correção
- M600/M610 criados automaticamente passam a ser inseridos antes de M800/M810;
- ordem final esperada: `... M500/M505 → M600/M610 → M800/M810 → M990`;
- M990, 9900, 9990 e 9999 continuam sendo recalculados quando a estrutura muda;
- o Pré-PVA ganhou uma regra específica para detectar M600/M610 depois de M800/M810 antes de o arquivo chegar ao PGE.

### Teste real — MEGA T.O. 07/2026
Com a mesma planilha de 4.229 alterações:
- M600 ficou na linha 21737;
- M610 ficou na linha 21738;
- M800 ficou na linha 21739;
- M810 ficou na linha 21740;
- M990 ficou na linha 21741 com QTD_LIN_M = 26;
- 9999 ficou com QTD_LIN = 21797;
- Pré-PVA local: 5 erros fiscais remanescentes, sem erro de hierarquia do Bloco M.

### Testes automatizados
- 110 testes aprovados.
