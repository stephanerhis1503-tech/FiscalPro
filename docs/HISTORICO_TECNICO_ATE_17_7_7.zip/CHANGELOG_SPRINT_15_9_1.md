# CHANGELOG — Sprint 15.9.1

- Corrigida a geração de TXT no fluxo Correção Assistida.
- Saída UTF-8 sem BOM quando a origem estiver em UTF-8/UTF-8-SIG.
- Preservadas codificações legadas como CP1252 e Latin-1.
- Nenhuma regra tributária ou registro SPED foi alterado.
