# FiscalPro — Hotfix 17.3.10

## Saneamento automático de COD_ITEM duplicado

### Problema corrigido
O PGE rejeita ocorrências repetidas da chave `COD_ITEM` no registro `0200`. Até a 17.3.9, essas pendências permaneciam como revisão manual.

### Nova regra em lote
- Cadastros `0200` integralmente idênticos: mantém o primeiro e remove a cópia redundante.
- Mesmo `COD_ITEM` usado em cadastros materialmente diferentes: preserva os dois cadastros e renomeia somente o posterior com sufixo `-D2`, `-D3` etc.
- Filhos do `0200` (`0205`, `0206`, `0210`, `0220`, `0221`) são preservados; quando uma cópia idêntica é removida, o bloco filho equivalente é removido junto.
- O FiscalPro não tenta adivinhar qual C170 pertencia a um cadastro divergente quando o arquivo de origem não traz evidência objetiva para esse vínculo.
- A tela de Correção Assistida passa a exibir uma única ação verde em lote para todos os `COD_ITEM` duplicados, evitando marcação item a item.
- Quando há exclusão estrutural, `9900`, fechamentos e `9999` são recalculados automaticamente.

### Teste com SPED real Mega Mix — 07/2026
- Antes: 159 causas raiz / 277 ocorrências equivalentes estimadas no PGE / 3 avisos.
- Depois das correções automáticas: 1 causa raiz / 1 ocorrência equivalente estimada / 0 avisos.
- Pendência restante: CFOP `1929` rejeitado pelo PGE.

### Testes automatizados
23 testes aprovados.
