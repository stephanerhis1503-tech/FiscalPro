# FiscalPro — Sprint 16.5.0

## Motor Nacional de PIS/COFINS — etapa segura

### Entregue

- Motor único de análise de PIS/Pasep e Cofins.
- Integração com a Consulta Tributária.
- Nova janela **Base PIS/COFINS**.
- Confirmação automática da revenda monofásica de autopeças, pneus e câmaras já mapeados na Lei nº 10.485/2002.
- Confirmação de operação de exportação explicitamente informada, com CST 08.
- Sugestões condicionais conforme regime:
  - Lucro Real/não cumulativo: CST 01, PIS 1,65% e Cofins 7,60%;
  - Lucro Presumido/cumulativo: CST 01, PIS 0,65% e Cofins 3,00%.
- Preservação de cadastros existentes e alerta de divergência.
- Catálogo das Tabelas 4.3.10 a 4.3.16 da EFD-Contribuições.
- Bloqueio de aplicação automática em entrada, Simples Nacional, EX TIPI incompleto e competências posteriores a 2026.

### Regra de segurança

A alíquota-padrão do regime é uma sugestão, não uma confirmação por NCM. O FiscalPro só grava automaticamente uma conclusão quando a regra especial está objetivamente confirmada pelo contexto informado.

### Próximas etapas

A importação integral das linhas das Tabelas 4.3.13, 4.3.14, 4.3.15 e 4.3.16 será feita em pacotes posteriores, com vigência, código da natureza da receita e condições legais. Nesta Sprint, a infraestrutura está pronta e as regras já validadas foram integradas.
