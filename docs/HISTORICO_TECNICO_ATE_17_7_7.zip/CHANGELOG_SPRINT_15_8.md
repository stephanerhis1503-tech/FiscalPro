# FiscalPro — Sprint 15.8

## Refinamento visual e relatórios ampliados

- Redução proporcional das fontes da interface, botões, abas e tabelas.
- Cabeçalho, rodapé, cards, contexto do arquivo e ações rápidas mais compactos.
- Área **Resultado da análise** ampliada de forma permanente na página principal.
- Relatório de correções com mais altura útil e fonte monoespaçada menor.
- Tabelas com linhas mais compactas, mantendo leitura e rolagem completas.
- SPED Inteligente com cabeçalho e faixa de comandos menores, liberando espaço para relatórios.
- Painéis do Robô Fiscal refinados sem remover funções.
- Versão da interface e do instalador atualizada para 15.8.

## Compatibilidade

- Preserva as Sprints 15.7, 15.7.1 e 15.7.2.
- Não altera regras fiscais, bancos, documentos, senhas, backups ou credenciais.
