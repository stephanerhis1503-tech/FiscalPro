# FiscalPro — Sprint 16.1.2

## Correção principal

- Corrigida a montagem incompleta da `JanelaSPEDInteligente` causada pela constante `RIGHT` não importada.
- A barra `progresso` e o rótulo de status agora são criados antes das abas da tela.
- O callback de progresso passou a ser defensivo: falhas de interface não interrompem leitura, auditoria ou geração do SPED.
- O instalador remove o cache compilado da tela para garantir o carregamento do código corrigido.

## Preservado

- Contas a Pagar e integração com o Robô FiscalPro da Sprint 16.1.
- Fluxo final unificado da Sprint 15.10.
- Correções assistidas, estorno ICMS, Excel → TXT e pré-validador.
