# Robô FiscalPro — Sprint 2.3

## Controle de Pendências Mensais

- Comparação automática entre documentos recebidos e documentos esperados por empresa.
- Checklist simples para XML, Guias, PDF, ZIP e Outros.
- Padrão conservador: somente Guias ficam marcadas inicialmente.
- Novas colunas Esperados e Faltando no Painel Mensal.
- Situações: Completo, Faltam, Revisar pendências e Sem documentos.
- Links pendentes e erros mantêm prioridade na situação do mês.
- Exportação CSV ampliada com documentos esperados e faltantes.
- Compatibilidade com o config.json e o robo_email.db existentes.
- Teste automatizado TESTE_ROBO_SPRINT_2_3.py.
