# Robô FiscalPro — Sprint 2.5

## Leitura e conferência inteligente de documentos

- Criado o leitor conservador de XMLs, PDFs e guias fiscais.
- NF-e e CT-e passam a fornecer número do documento, CNPJs, competência, valor total e vencimento quando esses campos existirem no XML.
- PDFs pesquisáveis passam a fornecer, quando localizados, tipo de guia, tributo, CNPJ, competência, valor, vencimento e número do documento.
- PDFs digitalizados ou sem texto pesquisável permanecem sinalizados para revisão; nenhum valor é inventado.
- O conteúdo do documento pode identificar a empresa pelo CNPJ cadastrado, mesmo quando o alias do Gmail não for reconhecido.
- Quando o CNPJ do documento não corresponder ao CNPJ da empresa selecionada, o arquivo recebe alerta de empresa divergente.
- Datas de vencimento já passadas são mostradas como **VENCIMENTO PASSADO**, com orientação para conferir pagamento ou atualização da guia.

## Painel mensal

- Adicionada a coluna **Conferência**, com quantidades de documentos conferidos, para revisar e com vencimento passado.
- A janela **Ver documentos salvos** ganhou CNPJ, competência, valor, vencimento, resumo da leitura, situação e alertas.
- Adicionado o botão **Ver conferência** para apresentar os dados extraídos de forma simples.
- Adicionado o botão **Analisar documentos** para reler os arquivos já registrados no período sem movê-los ou renomeá-los.
- O relatório CSV mensal também inclui o resumo da conferência inteligente.

## Cadastro e banco

- A tela **Documentos esperados** agora permite informar o CNPJ de cada uma das seis empresas.
- O banco do robô recebe novas colunas por migração automática, sem apagar registros existentes.
- São armazenados tipo, número, CNPJ, competência, valor, vencimento, tributo, fonte da leitura, resumo, situação e alertas.
- Adicionada a dependência `pypdf` ao instalador do Robô FiscalPro.
- O banco, token do Gmail, credenciais e documentos da usuária não fazem parte da entrega.

## Validação

- Adicionado `TESTE_ROBO_SPRINT_2_5.py` com NF-e, identificação da empresa por CNPJ, leitura de DARF em PDF e conferência do painel mensal.
- Mantida a compatibilidade com a Sprint 2.4 aprovada.
