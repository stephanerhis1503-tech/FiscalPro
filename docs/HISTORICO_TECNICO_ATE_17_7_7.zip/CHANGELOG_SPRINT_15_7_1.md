# FiscalPro — Sprint 15.7.1

## Correção de compatibilidade com o PVA

- remove o BOM UTF-8 dos arquivos SPED TXT gerados;
- garante que o primeiro byte do arquivo seja o separador `|` do registro `0000`;
- corrige Excel → TXT, Estorno de ICMS, Pré-Validador, Correção Assistida e Correção Tributária Assistida;
- mantém BOM somente em relatórios auxiliares e CSVs, que não são importados no PVA.

O erro corrigido era: “O registro obrigatório 0000 não foi encontrado”.
