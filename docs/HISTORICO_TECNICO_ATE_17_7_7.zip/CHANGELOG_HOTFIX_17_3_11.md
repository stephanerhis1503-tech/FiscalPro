# FiscalPro — Hotfix 17.3.11

## CFOP automático de combustível

### Problema
O PGE 6.1.2 rejeitou o CFOP `1929` em um C170 referente à compra de `GASOLINA COMUM`. O documento é uma entrada e a chave da NF-e identifica emitente da mesma UF da empresa.

### Regra nova
Quando todas as evidências estiverem presentes:
- registro `C170` com CFOP `1929`;
- item cadastrado no `0200` identificado objetivamente como combustível (descrição/NCM);
- documento pai `C100` com `IND_OPER=0`;
- chave da NF-e válida para identificar a UF do emitente;

o FiscalPro sugere e marca automaticamente:
- `1653` para compra de combustível/lubrificante por consumidor ou usuário final dentro da UF;
- `2653` para a mesma operação com fornecedor de outra UF.

Não há troca automática quando a natureza do item ou a UF não puderem ser comprovadas.

### Validação real
No SPED Mega Mix 07/2026, a linha do combustível foi corrigida de `1929` para `1653`.
Após aplicar o conjunto de correções automáticas acumuladas, o Pré-Validador local passou de `159 erros / 3 avisos` para `0 erros / 0 avisos`.

### Testes
27 testes automatizados aprovados.
