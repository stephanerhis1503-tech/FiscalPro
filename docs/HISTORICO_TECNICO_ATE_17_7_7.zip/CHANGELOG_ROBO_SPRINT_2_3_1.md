# Robô FiscalPro — Sprint 2.3.1

## Correção

- Corrigido o bloqueio do banco SQLite temporário no Windows.
- Todas as conexões do repositório do Robô FiscalPro agora são confirmadas ou revertidas e fechadas explicitamente.
- Evita `PermissionError: [WinError 32]` ao executar o teste, mover, copiar ou excluir bancos temporários.
- O teste da Sprint 2.3 foi ampliado para confirmar que o arquivo `.db` pode ser movido e excluído antes da limpeza da pasta temporária.

## Compatibilidade

- Preserva o banco real `dados/robo_email/robo_email.db`.
- Não altera token do Gmail, credenciais, configurações ou documentos baixados.
- Mantém as funcionalidades aprovadas da Sprint 2.3.
