# FiscalPro — Sprint 16.1.3

## Registros 0205 e 0220 não bloqueantes

- Permite remover registros `0205` e `0220` da planilha reversível sem bloquear a geração do TXT.
- A remoção aparece como **AVISO**, não como erro.
- Recalcula automaticamente `0990`, `9900`, `9990`, `9999` e demais fechamentos existentes.
- Mantém o bloqueio para qualquer outro registro original apagado.
- Reclassifica futuros apontamentos diretos de `0205` e `0220` no Pré-Validador como avisos.
- Preserva a geração em UTF-8 sem BOM.
