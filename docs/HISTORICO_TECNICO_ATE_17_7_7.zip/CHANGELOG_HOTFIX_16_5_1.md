# Hotfix 16.5.1 — Indicadores de segurança do PIS/COFINS

- Separado o indicador específico de PIS/COFINS da pontuação geral do parecer.
- Enquadramentos oficialmente confirmados passam a exibir **Segurança PIS/COFINS: 100% — CONFIRMADA**.
- A antiga linha genérica foi renomeada para **Segurança geral do parecer**.
- Incluída explicação de que a pontuação geral também considera ICMS, ICMS-ST, IPI, benefícios, Reforma Tributária, contexto e fontes.
- Mantidos intactos CSTs, alíquotas, cálculos, regras e bases tributárias.
- Adicionados cinco testes automatizados.
