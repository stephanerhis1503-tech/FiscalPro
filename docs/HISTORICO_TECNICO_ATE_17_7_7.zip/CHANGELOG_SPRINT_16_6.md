# FiscalPro — Sprint 16.6.0

## Motor ICMS, ICMS-ST e benefícios de Minas Gerais

Data: 05/08/2026

### Entregas

- Novo botão **Base ICMS/MG** na Consulta Tributária.
- Motor separado para:
  - alíquota nominal da operação;
  - enquadramento no ICMS-ST de Minas Gerais;
  - benefício fiscal reconhecido de forma objetiva;
  - pendências que exigem revisão humana.
- Regras interestaduais nacionais de 7%, 12% e 4% para mercadorias importadas, com tratamento conservador das exceções.
- Regra interna residual de 18% apresentada como **condicional**, sem sobrescrever cadastro tributário.
- Confirmação específica de 25% para posições 3303 a 3307 e de 12% para veículos dos segmentos 25 e 26 quando o enquadramento oficial estiver disponível.
- Benefício do Anexo II, item 30, para saída interestadual de pneumáticos e câmaras promovida por fabricante/importador, respeitando as condições informadas.
- Cobertura offline preservada com 247 registros validados dos segmentos de autopeças, materiais de construção/congêneres e pneumáticos.
- Atualizador ampliado da Parte 2 do Anexo VII para importar capítulos que apresentem CEST, NCM, descrição, âmbito e MVA numérica estruturada.
- A base anterior é preservada se a atualização ampla parecer incompleta.
- Novo indicador independente **Segurança ICMS/MG** na Ficha Inteligente.
- Integração do motor ao fluxo de consulta, sem gravar alíquota condicional como definitiva.
- Versão do aplicativo e do futuro instalador atualizada para 16.6.0.
- Dez testes automatizados sem acesso à internet e sem alterar o banco real.

### Limites de segurança

- Ausência de NCM na cobertura local não significa ausência de ICMS-ST.
- PMPF, preço fixado, pauta, benefícios subjetivos, regimes especiais e capítulos sem MVA numérica permanecem para revisão.
- A alíquota interna residual de 18% não é confirmada automaticamente por NCM.
- A alíquota de 4% depende da origem/conteúdo de importação e das exceções legais.
- A responsabilidade pelo ICMS-ST interestadual pode depender do âmbito, acordo vigente, sujeito passivo e condições da operação.
