# FiscalPro — Sprint 15.6

## Ajustes globais de layout e responsividade

- A janela principal agora respeita a área útil do monitor e maximiza automaticamente em notebooks com pouca altura.
- Todas as abas principais preservam uma área útil mínima para resultados, tabelas e relatórios.
- A tela SPED Inteligente teve as antigas barras verticais reunidas em abas compactas de comandos.
- As abas Mapa, CT-e, Correções, Auditoria Tributária, Correção Tributária, Pré-PVA, Correção Assistida e Excel → TXT passam a ocupar o espaço restante da janela.
- O resultado da validação Excel → TXT ganhou altura útil, rolagem vertical e horizontal e deixou de ficar achatado.
- Tabelas, campos e painéis foram ajustados para monitores de notebook e telas maiores.
- Janelas de Ficha Tributária, Simulador, XML → ICMS-ST, Calculadora ST, Consulta NCM, Backup e painéis do Robô Fiscal agora são dimensionadas conforme o monitor.
- F11 alterna a maximização nas janelas responsivas.
- Botões, abas e linhas das tabelas ficaram um pouco mais compactos para ampliar a área de leitura sem perder legibilidade.
- Nenhuma regra fiscal, cálculo, banco de dados ou automação foi alterada.

## Validação

Execute:

```powershell
python TESTE_SPRINT_15_6.py
```

Resultado esperado:

```text
✅ Sprint 15.6 validada com sucesso.
```
