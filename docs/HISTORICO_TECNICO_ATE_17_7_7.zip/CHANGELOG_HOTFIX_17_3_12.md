# FiscalPro — Hotfix 17.3.12

## ICMS do SPED Fiscal → bases de crédito PIS/COFINS

### Novo fluxo
- A EFD Contribuições pode importar o **ICMS próprio já corrigido no SPED Fiscal**.
- O cruzamento é estrito por **CHV_NFE + NUM_ITEM + COD_ITEM**.
- A automação é limitada a entradas de terceiros de compra para revenda com CFOP **1102/2102**, ICMS próprio maior que zero e CST de crédito PIS/COFINS **50 a 66**.
- O ICMS-ST não é usado nesse cálculo.
- Se a base já estiver líquida do ICMS, o item é reconhecido e preservado, impedindo dupla exclusão.

### Recálculo encadeado
Após excluir o ICMS próprio das bases do C170, o FiscalPro recalcula:
- VL_BC_PIS e VL_BC_COFINS;
- VL_PIS e VL_COFINS;
- totais de PIS/COFINS do C100;
- bases dos M105/M505 vinculados ao bloco C, preservando a NAT_BC_CRED existente;
- M100/M500;
- créditos descontados e valores devidos/recolher de M200/M600.

A atualização do Bloco M só é automática em apuração simples e comprovada: sem ajustes, diferimento, saldo de crédito ou vínculo ambíguo. Caso contrário, a geração é bloqueada para revisão.

### Teste real — Mega Mix 07/2026
Fonte Fiscal corrigida e EFD Contribuições cruzadas sem aproximação:
- 15 notas;
- 170 itens;
- R$ 53.251,92 de ICMS próprio excluído das bases;
- redução efetiva de PIS: R$ 757,27;
- redução efetiva de COFINS: R$ 3.488,64;
- 42 campos do Bloco M sincronizados;
- Pré-Validador local após a geração: 0 erros / 0 avisos.

### Testes
- 31 testes automatizados aprovados.
