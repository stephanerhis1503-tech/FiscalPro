# FiscalPro - Sprint 16.2.2

## Ajuste do período semanal

- A opção **Próxima semana** passa a considerar o período de **sábado a sexta-feira**.
- O início é sempre o próximo sábado posterior à data da consulta.
- Exemplo: em 04/08/2026, o período automático será de 08/08/2026 a 14/08/2026.
- Se o relatório for aberto em um sábado, a próxima semana começa no sábado seguinte.

## Relatórios preservados

- Consolidado ou separado por empresa;
- PDF e Excel;
- Subtotal por empresa e total geral;
- Período personalizado;
- Inclusão opcional de contas vencidas.

## Segurança

- Mantém a Sprint 16.1.3.1 e o recálculo dos totalizadores do SPED.
- Mantém as dependências locais de PDF instaladas na Sprint 16.2.1.
- Restaura automaticamente a versão anterior se qualquer teste falhar.
