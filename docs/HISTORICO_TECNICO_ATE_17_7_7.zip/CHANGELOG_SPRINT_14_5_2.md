# Sprint 14.5.2 — Correção XLSX

- Corrigida a ordem `autoFilter` / `mergeCells` no XML da planilha.
- Completada a configuração do congelamento de linhas e colunas.
- Corrigido o formato monetário para utilizar o padrão `R$`.
- Adicionado teste de integridade do pacote XLSX.
