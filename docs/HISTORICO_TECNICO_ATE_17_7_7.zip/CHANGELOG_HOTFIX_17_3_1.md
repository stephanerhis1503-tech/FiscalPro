# Hotfix 17.3.1 — Pré-Validador alinhado ao PGE

## Correções

- Removido o falso positivo que tratava todo registro C100 regular sem C170 como erro automático.
- O Pré-Validador passa a reconhecer C175 e C190 como formas alternativas de detalhamento/totalização associadas à análise do documento.
- Documentos complementares ou especiais sem valores materiais deixam de bloquear a pré-validação e passam a gerar apenas conferência preventiva.
- O erro de hierarquia permanece somente quando o C100 possui valores relevantes e nenhum C170, C175 ou C190 foi localizado.
- A mensagem antiga “Documento regular sem nenhum item C170” foi removida.

## Segurança

- Nenhuma linha do SPED é alterada por este hotfix.
- A correção afeta somente a classificação dos apontamentos do Pré-Validador.
- A validação oficial no PGE da EFD-Contribuições continua obrigatória.
- A regra da EFD ICMS/IPI não foi alterada.

## Testes

- 8 testes novos do Hotfix 17.3.1.
- Regressão simulada com 1.887 registros C100 acompanhados de C190, sem falso erro de C170 ausente.
- 12 testes da Sprint 17.3 novamente aprovados.
- 5 testes gerais do recálculo de PIS/COFINS aprovados.
