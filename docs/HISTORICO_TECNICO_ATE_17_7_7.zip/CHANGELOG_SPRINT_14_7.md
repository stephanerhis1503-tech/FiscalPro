# FiscalPro — Sprint 14.7

## Parafusos e itens semelhantes — NCM 7318 / ICMS-ST MG

### Implementado

- Sincronização do segmento 10 — Materiais de construção e congêneres — do Anexo VII do RICMS/MG.
- Reconhecimento do item 58.0, CEST 10.058.00, NCM 7318 e MVA original de 50%.
- Leitura conjunta dos âmbitos 10.1 e 10.2.
- Pergunta simples ao importar XML com itens NCM 7318:
  - passível de uso na construção/congêneres;
  - uso exclusivamente automotivo;
  - revisão individual.
- Edição individual da aplicabilidade do NCM 7318 por duplo clique no item.
- Bloqueio do cálculo enquanto a aplicabilidade estiver pendente.
- Não aplicação do segmento 10 quando houver declaração de uso exclusivamente automotivo.
- Inclusão da classificação adotada na planilha de conferência.
- Fórmulas de ST desativadas nas linhas pendentes ou não aplicáveis, evitando cálculo indevido no Excel.
- Fundamentação complementar com o Acórdão nº 25.475/26/3ª do Conselho de Contribuintes de Minas Gerais.

### Preservado

- Importação de XML.
- Cálculo de MVA ajustada e ICMS-ST.
- Conferência entre ST do XML e ST calculado.
- Coluna Valor do item + IPI.
- Correção estrutural da planilha Excel da Sprint 14.5.2.
- Segmentos de autopeças e pneumáticos já aprovados.
