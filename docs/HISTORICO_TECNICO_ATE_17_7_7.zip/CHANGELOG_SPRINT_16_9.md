# FiscalPro — Sprint 16.9.0

## Contas a Pagar Simplificado

- Reduzida a tela de lançamento aos dados principais: empresa, fornecedor, categoria, valor, vencimento e competência.
- Campos menos usados foram movidos para **Detalhes opcionais**, que ficam recolhidos por padrão.
- Criado cadastro persistente de fornecedores: ao salvar uma conta, o fornecedor passa a aparecer nos próximos lançamentos.
- Fornecedores já existentes nas contas e na fila do Robô FiscalPro são migrados automaticamente para a nova lista.
- Adicionada pesquisa rápida no campo de fornecedor enquanto a usuária digita.
- Adicionado botão **Nova categoria** diretamente na tela do lançamento.
- Datas de vencimento e pagamento passaram a usar calendário visual, sem dependência externa.
- Competência passou a ser selecionada em lista mensal, de 01/2026 a 12/2026, expandindo automaticamente quando novos anos chegarem ou quando houver datas futuras.
- Ao escolher o vencimento no calendário, a competência correspondente é preenchida automaticamente.
- Corrigida a validação de competência para impedir meses inválidos, como 13/2026.
- Atualizados metadados do aplicativo, executável e instalador para a versão 16.9.0.
- Adicionados nove testes automatizados.
