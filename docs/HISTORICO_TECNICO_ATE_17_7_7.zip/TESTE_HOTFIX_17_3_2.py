from __future__ import annotations

import unittest

from src.core.app_info import VERSAO_APP
from src.ui.painel_contas_pagar import JanelaContaPagar


class VariavelFalsa:
    def __init__(self, valor=""):
        self.valor = valor

    def get(self):
        return self.valor

    def set(self, valor):
        self.valor = valor


class TextoFalso:
    def __init__(self, valor=""):
        self.valor = valor

    def get(self, *_args):
        return self.valor

    def delete(self, *_args):
        self.valor = ""


class ComboFalso:
    def __init__(self):
        self.focado = False

    def focus_set(self):
        self.focado = True


class JanelaFalsa:
    def __init__(self):
        self.destruida = False

    def destroy(self):
        self.destruida = True

    def after_idle(self, callback):
        callback()


class RepositorioFalso:
    def __init__(self):
        self.fila_atualizada = False

    def atualizar_status_fila(self, *_args):
        self.fila_atualizada = True


class ServicoFalso:
    def __init__(self):
        self.repositorio = RepositorioFalso()
        self.salvamentos = 0

    def salvar_conta(self, _dados, conta_id=None, permitir_duplicidade=False):
        self.salvamentos += 1
        return (conta_id or 321), []


class TestHotfix1732(unittest.TestCase):
    def _janela(self, *, conta_id=None, fila_id=None):
        objeto = JanelaContaPagar.__new__(JanelaContaPagar)
        objeto.conta_id = conta_id
        objeto.fila_id = fila_id
        objeto.servico = ServicoFalso()
        objeto.janela = JanelaFalsa()
        objeto.origem = "MANUAL"
        objeto.robo_documento_id = None
        objeto.ao_salvar_chamado = False
        objeto.ao_salvar = lambda: setattr(objeto, "ao_salvar_chamado", True)
        objeto.vars = {
            "empresa": VariavelFalsa("Mega Motos Comércio"),
            "fornecedor": VariavelFalsa("Fornecedor Teste"),
            "descricao": VariavelFalsa("Energia elétrica"),
            "categoria": VariavelFalsa("ENERGIA"),
            "valor": VariavelFalsa("125,00"),
            "vencimento": VariavelFalsa("20/08/2026"),
            "data_pagamento": VariavelFalsa(""),
            "numero_documento": VariavelFalsa("ABC123"),
            "competencia": VariavelFalsa("08/2026"),
            "caminho_documento": VariavelFalsa("C:/documento.pdf"),
        }
        objeto.txt_observacoes = TextoFalso("Observação")
        objeto.var_feedback_salvamento = VariavelFalsa()
        objeto.cbo_fornecedor = ComboFalso()
        objeto._atualizar_fornecedores = lambda: None
        objeto._atualizar_categorias = lambda: None
        objeto._atualizar_competencias = lambda selecionar=None: None
        objeto._alternar_detalhes = lambda mostrar=None: None
        return objeto

    def test_01_novo_cadastro_manual_continua_aberto(self):
        janela = self._janela()
        janela._salvar()
        self.assertFalse(janela.janela.destruida)
        self.assertTrue(janela.ao_salvar_chamado)
        self.assertIn("Cadastre a próxima", janela.var_feedback_salvamento.get())

    def test_02_formulario_limpa_dados_variaveis(self):
        janela = self._janela()
        janela._salvar()
        for chave in (
            "fornecedor", "descricao", "valor", "vencimento",
            "data_pagamento", "numero_documento", "caminho_documento",
        ):
            self.assertEqual("", janela.vars[chave].get(), chave)
        self.assertEqual("", janela.txt_observacoes.valor)
        self.assertTrue(janela.cbo_fornecedor.focado)

    def test_03_empresa_e_competencia_sao_mantidas(self):
        janela = self._janela()
        janela._salvar()
        self.assertEqual("Mega Motos Comércio", janela.vars["empresa"].get())
        self.assertEqual("08/2026", janela.vars["competencia"].get())
        self.assertEqual("OUTROS", janela.vars["categoria"].get())

    def test_04_edicao_fecha_apos_salvar(self):
        janela = self._janela(conta_id=77)
        janela._salvar()
        self.assertTrue(janela.janela.destruida)

    def test_05_importacao_da_fila_fecha_e_finaliza_documento(self):
        janela = self._janela(fila_id=88)
        janela._salvar()
        self.assertTrue(janela.janela.destruida)
        self.assertTrue(janela.servico.repositorio.fila_atualizada)

    def test_06_cadastro_manual_e_edicao_sao_identificados_corretamente(self):
        self.assertTrue(self._janela()._cadastro_manual_novo())
        self.assertFalse(self._janela(conta_id=1)._cadastro_manual_novo())
        self.assertFalse(self._janela(fila_id=1)._cadastro_manual_novo())

    def test_07_versao_atualizada(self):
        self.assertEqual("17.3.2", VERSAO_APP)


if __name__ == "__main__":
    unittest.main(verbosity=2)
