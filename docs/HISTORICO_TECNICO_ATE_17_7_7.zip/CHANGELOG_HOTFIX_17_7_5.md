# Hotfix 17.7.5 — Ordem Hierárquica do Bloco M no Excel → TXT

## Problema reproduzido
Na planilha real `SPED CONT 07-2026_ORGANIZADO3.xlsx`, a usuária excluiu grupos de crédito que não deveriam existir e reaproveitou um M105 e um M505 para os grupos sobreviventes. A aba técnica, porém, ainda guardava a posição ORIGINAL desses filhos. O TXT gerado pelo 17.7.3 saía como `M105 → M100` e `M505 → M500`, e o PGE rejeitava a organização hierárquica.

O 17.7.4 removia filhos ligados ao pai original excluído. Isso era correto para filhos não alterados, mas não para um filho que a usuária havia editado conscientemente para representar outro grupo.

## Correção
- Filho M105/M505 **não alterado** de um pai excluído continua sendo removido pela proteção 17.7.4.
- Filho M105/M505 **editado** pela usuária é preservado.
- Se a base atual identificar de forma **única** um novo M100/M500, o FiscalPro reposiciona o filho após o pai correto.
- A geração passa a respeitar `M100 → M105` e `M500 → M505`.
- O reposicionamento aparece na Conferência Excel como **Reposicionamento hierárquico**.
- Se a base não provar um único pai, o FiscalPro não adivinha e apenas emite aviso para revisão.
- A correção é feita **depois** da assistência aritmética do modo manual, portanto não altera valores digitados somente para corrigir a ordem.

## Reprodução real validada
Com a planilha enviada pela usuária, o TXT produzido pelo hotfix ficou com 10.249 linhas e o Bloco M passou a sair exatamente:

- M100 na linha 10172
- M105 na linha 10173
- M500 na linha 10181
- M505 na linha 10182
- M990 = 20
- 9999 = 10249

O arquivo reconstruído pelo FiscalPro ficou **idêntico linha a linha** ao TXT que a usuária havia corrigido manualmente (`SPED CONT 07-2026 3.txt`): 0 diferenças em 10.249 linhas.

## Testes
142 testes automatizados aprovados.
