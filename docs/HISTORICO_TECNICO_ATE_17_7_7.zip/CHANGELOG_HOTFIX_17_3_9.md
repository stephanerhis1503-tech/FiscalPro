# FiscalPro — Hotfix 17.3.9

## Consolidação automática de créditos duplicados no Bloco M

- Duplicidades seguras de `M100` e `M500` deixam de aparecer como **Somente revisão**.
- O FiscalPro agrupa a chave exigida pelo PGE: `COD_CRED + IND_CRED_ORI + ALIQ + ALIQ_QUANT`.
- Os registros `M105`/`M505` dos créditos consolidados são preservados e reposicionados sob o único pai resultante.
- A base do crédito é conciliada pelos filhos e o valor do crédito é recalculado sobre a base consolidada, evitando diferença de arredondamento.
- A automação só é habilitada quando não existem ajustes, diferimentos, saldo de crédito ou chaves filhas repetidas que exijam decisão fiscal.
- Após remover pais duplicados, o FiscalPro recalcula `M990`, `9900`, `9990` e `9999` na mesma geração.

## Teste real — MEGA MIX 07/2026

- M100 linhas originais 33723 + 33727: base consolidada `731047,80`, crédito PIS `12062,29`.
- M500 linhas originais 33732 + 33736: base consolidada `731047,80`, crédito COFINS `55559,63`.
- Pré-validação interna, após todas as correções automáticas seguras da série 17.3.7–17.3.9: **159 → 7 causas raiz**, mantendo 3 avisos.
- Suíte automatizada: **18 testes aprovados**.
