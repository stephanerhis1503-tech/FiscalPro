# FiscalPro — Sprint 16.4.0

## Base Nacional de NCM e TIPI

### Entregue

- Pacote offline derivado da TIPI oficial atualizada pelo ADE RFB nº 1/2026.
- 10.520 códigos NCM garantidos no pacote offline e 11.102 registros TIPI, incluindo EX.
- Mesclagem segura com a NCM oficial do Classif já sincronizada pelo FiscalPro, preservando códigos mais recentes e chegando a 11.423 códigos na base testada da versão 16.2.2.
- Descrição hierárquica completa dos produtos para reduzir resultados genéricos como “Outros”.
- Pesquisa por código, palavras, acentos e descrição do produto.
- Nova janela **Catálogo de NCM** integrada à Consulta Tributária.
- Exibição da alíquota principal de IPI e da quantidade de EX TIPI.
- Consulta oficial disponível sem internet após a instalação da Sprint.
- Receita Federal corrigida para consultar `ncm_oficial` e `tipi_oficial`.
- Empacotamento da base nacional no executável e atualização da versão para 16.4.0.

### Segurança tributária

A Sprint 16.4 não cria uma tributação única para cada NCM. Quando não existe regra específica validada, o FiscalPro confirma somente NCM, descrição e TIPI/IPI e deixa ICMS, ICMS-ST, PIS, Cofins e CSTs sem preenchimento por aproximação.

### Arquivos principais

- `dados/bases_oficiais/base_ncm_tipi_2026_02_13.json.gz`
- `src/services/base_ncm_nacional_service.py`
- `src/ui/janela_catalogo_ncm.py`
- `src/inteligencia/base_oficial/repositorio.py`
- `src/inteligencia/fontes/receita_federal.py`
- `src/repositorios/tributacao_repository.py`
- `TESTE_SPRINT_16_4.py`
- `TESTAR_SPRINT_16_4.bat`
