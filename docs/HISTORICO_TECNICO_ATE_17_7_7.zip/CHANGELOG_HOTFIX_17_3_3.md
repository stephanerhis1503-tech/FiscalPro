# Hotfix 17.3.3 — Pendências reais do PGE no Pré-Validador

## Problema corrigido

Um SPED de EFD-Contribuições podia apresentar erros no PGE e, ao mesmo tempo, o FiscalPro informar 0 erros porque o Pré-Validador ainda não cobria algumas validações específicas do leiaute.

## Novas validações

- Registro 0205:
  - valida DT_INI e DT_FIM;
  - bloqueia DT_FIM que não seja anterior ao DT_FIN da competência do registro 0000;
  - detecta períodos históricos sobrepostos para o mesmo item.
- Registro C175:
  - detecta bases de PIS e COFINS divergentes quando o CST é o mesmo;
  - confere cálculo percentual de PIS/COFINS;
  - detecta combinação repetida de CFOP/CST/alíquotas no mesmo C100.
- Blocos A e D da EFD-Contribuições:
  - detecta IND_MOV=0 sem registros operacionais do respectivo bloco.

## Caso real usado na regressão

No arquivo `SPED CONT MEGA COMERCIO 05-2026`, a versão anterior retornava:

- 0 erros;
- 0 avisos.

Com o Hotfix 17.3.3, o Pré-Validador localizou 16 pendências:

- 3 datas DT_FIM do 0205 fora da competência;
- 9 sobreposições de períodos do 0205;
- 2 divergências de base PIS/COFINS no C175;
- 1 Bloco A marcado com movimento sem registro operacional;
- 1 Bloco D marcado com movimento sem registro operacional.

## Segurança

- O Pré-Validador continua somente lendo o SPED; nenhuma linha é alterada.
- As regras novas são aplicadas antes de qualquer correção assistida.
- A validação oficial no PGE continua sendo a referência final.
- O Hotfix 17.3.1, que eliminou o falso erro de C100 sem C170, foi preservado.
