# Hotfix 17.2.3 — Busca rápida no Contas a Pagar

## Alterações

- O campo **Fornecedor / beneficiário** filtra os nomes gravados enquanto a usuária digita.
- O campo **Categoria** também ganhou busca automática enquanto a usuária digita.
- As sugestões consideram apenas nomes que **começam** com o texto informado.
- A lista de resultados abre automaticamente, sem precisar usar a barra de rolagem.
- A busca ignora diferenças entre letras maiúsculas, minúsculas e acentos.
- Fornecedores e categorias novos continuam sendo gravados normalmente.

## Segurança

- Nenhuma conta já cadastrada é alterada.
- Valores, datas, competências, pagamentos, documentos e relatórios permanecem inalterados.
- O hotfix modifica somente a experiência de seleção dos campos Fornecedor e Categoria.
