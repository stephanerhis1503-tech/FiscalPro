# Robô FiscalPro — Sprint 2.4

## Organização automática de documentos

- Criado o organizador central do Robô FiscalPro para anexos do Gmail, downloads automáticos por link e arquivos importados pelo modo assistido do Nibo.
- A duplicidade passa a ser verificada pelo conteúdo SHA-256 antes da gravação, inclusive quando o mesmo arquivo chega por outra empresa ou outro canal.
- XMLs de NF-e e CT-e recebem nome padronizado com competência, tipo, número e chave de acesso quando essas informações estiverem disponíveis.
- Guias, PDFs, ZIPs e outros documentos recebem nomes claros iniciados por `AAAA-MM`.
- A competência é definida, nesta ordem, pela data de emissão do XML, pela competência informada no nome/assunto ou pela data do e-mail.
- Mantida a estrutura simples `Empresa > Ano > Mês > Tipo de documento`.
- Documentos cuja empresa não puder ser identificada são enviados para `_Revisar > Ano > Mês > Tipo`.
- Arquivos de tipo não confirmado continuam sinalizados para revisão, sem classificação inventada.

## Painel mensal

- Adicionado o botão **Ver documentos salvos**, com nome original, nome organizado, origem, situação, data e caminho completo.
- É possível abrir o documento ou a pasta diretamente pela nova janela.
- Adicionado acesso rápido à pasta **Revisar não identificados**.
- O resumo mensal mostra quantos documentos do período aguardam revisão.
- Documentos antigos permanecem visíveis no painel mesmo quando ainda não possuem os novos metadados no banco.

## Banco e compatibilidade

- O banco local recebe novas colunas de organização por migração automática, sem apagar registros existentes.
- São gravados categoria, competência, nome padronizado, origem, situação e detalhe da organização.
- O `fiscalpro.db`, o banco do robô, o token do Gmail, credenciais e documentos da usuária não fazem parte da entrega.
- Mantidas as funcionalidades aprovadas das Sprints 2.1, 2.2, 2.3 e 2.3.1.
