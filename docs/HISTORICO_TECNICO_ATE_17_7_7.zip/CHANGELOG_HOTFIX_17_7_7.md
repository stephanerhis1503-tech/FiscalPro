# Hotfix 17.7.7 — Precisão Decimal por Campo no SPED ↔ Excel

## Diagnóstico
A revisão do fluxo TXT → Excel → TXT mostrou que o FiscalPro ainda tratava a
precisão decimal pelo texto genérico do cabeçalho. Após a adoção dos nomes
técnicos oficiais (`ALIQ_PIS`, `QUANT_BC_PIS`, `QTD` etc.), alguns campos já
nem eram reconhecidos como numéricos. Além disso, a planilha não recebia um
formato visual fixo por campo.

## Correção
- `QTD`: 5 casas decimais.
- Valores e bases monetárias (`VL_*`, valores, descontos): 2 casas.
- `ALIQ_ICMS`, `ALIQ_ST`, `ALIQ_IPI`: 2 casas.
- `ALIQ_PIS`, `ALIQ_COFINS`: 4 casas.
- `QUANT_BC_PIS`, `QUANT_BC_COFINS`: 3 casas.
- `ALIQ_PIS_QUANT`, `ALIQ_COFINS_QUANT`: 4 casas.
- Totalizadores de quantidade de linhas/registros: inteiros.
- A exportação agora aplica o formato numérico diretamente às células do Excel.
- A importação Excel → TXT usa a mesma tabela de precisão para serializar
  campos alterados.
- Células não alteradas continuam preservando exatamente o texto original do
  TXT, inclusive as casas decimais existentes.

## Referência de comparação
O arquivo de teste gerado pelo SYSCONV confirmou um comportamento útil: valores
como `0,65` no Excel retornam ao TXT como `0,6500`, e quantidades como `1`
retornam como `1,00000`. A lógica fiscal do SYSCONV não foi copiada; foi
identificada uma alteração indevida em C100 no round-trip de referência, então
apenas a estratégia de precisão por campo foi aproveitada como comparação.

## Segurança
A precisão usada para C170/C175 foi alinhada às especificações do Guia Prático
da EFD-Contribuições. O PGE continua sendo o validador oficial final.
