# Hotfix 17.3.5 — Espelho PGE Real

## Objetivo
Alinhar o Pré-Validador do FiscalPro ao relatório real do PGE EFD-Contribuições 6.1.2 usando como gabarito o arquivo MEGA MIX E-COMMERCE — 07/2026.

## Resultado do teste real
- SPED analisado: 33.789 linhas.
- FiscalPro identifica 159 causas raiz e 3 avisos relevantes.
- Equivalência calculada para o PGE: 277 ocorrências de erro e 3 avisos.
- O total de 277 é explicado por 98 repetições de regra de CST de entrada, 16 pendências encadeadas de M105/M505 e 4 pendências encadeadas de M400/M410/M800/M810.
- Correções automáticas determinísticas encontradas no arquivo: 148 causas diretas.
- O recalculador encadeado gera mais 92 ajustes dependentes em VL_PIS/VL_COFINS e totais dos C100.
- Após as correções automáticas: 11 causas raiz; equivalência estimada no PGE: 27 ocorrências; 3 avisos.

## Mudanças
- Adicionada equivalência de ocorrências do PGE sem duplicar a tabela do FiscalPro.
- CST de entrada continua sendo mostrado uma vez por campo, embora o PGE 6.1.2 repita a mesma causa em duas regras.
- Estimativa das cascatas de base M105/M505 quando há chaves M100/M500 duplicadas.
- Estimativa das cascatas M400/M410/M800/M810 causadas por CST 08 usado em aquisição.
- Aviso consolidado por COD_ITEM repetido: um aviso por código, igual ao padrão observado no PGE.
- Removido do Pré-Validador PGE o ruído de divergência UNID C170 x UNID_INV 0200, que não gerou pendência no PGE do arquivo-gabarito.
- Tela do Pré-Validador passa a exibir “causas raiz” e “equivalência estimada no PGE”.
- Relatório TXT do Pré-Validador grava o detalhamento da equivalência.

## Segurança
- O FiscalPro não inventa conta contábil, NAT_REC, CFOP ou consolidação de crédito.
- O Bloco M continua marcado para re-apuração oficial quando PIS/COFINS documental é alterado.
- Duplicidades de 0200 e M100/M500 permanecem como revisão manual.
