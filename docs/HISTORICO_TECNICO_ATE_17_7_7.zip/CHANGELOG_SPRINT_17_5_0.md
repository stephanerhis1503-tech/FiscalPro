# FiscalPro — Sprint 17.5.0

## Robô Tributário Inteligente — análise completa da operação

- Nova tela **Robô Tributário Inteligente** dentro da área de Inteligência Tributária.
- O robô recebe o contexto real da operação: NCM, descrição, UF origem/destino, regime, operação, finalidade e consumidor final.
- Cruza os motores já instalados do FiscalPro e apresenta diagnóstico separado de:
  - PIS/COFINS;
  - ICMS próprio;
  - ICMS-ST;
  - IPI;
  - Reforma Tributária 2026.
- Cada bloco é classificado como **CONFIRMADO**, **REVISAR**, **PENDENTE** ou **INFORMATIVO**.
- Status geral conservador: **CONSISTENTE**, **REVISAR** ou **PENDENTE**.
- Relatório explicável com contexto, alertas, fundamentos e fontes registradas.
- Botão para salvar o relatório em TXT.

## Evolução importante do motor

A descrição real informada para a operação passa a ter prioridade sobre a descrição genérica do cadastro/NCM nos motores de:

- ICMS/MG;
- ICMS-ST/MG;
- PIS/COFINS nacional.

Isso melhora enquadramentos em que o mesmo NCM depende da descrição efetiva do produto.

## Segurança

- O robô não cria tributação por aproximação.
- NCM não encontrado ou ICMS-ST não localizado ficam como **PENDENTE**, e não como “sem tributação”.
- Divergência entre regra oficial e cadastro existente fica como **REVISAR**.
- O cenário-padrão da Reforma 2026 permanece como **REVISAR** até existir enquadramento específico.
- Nenhuma correção é aplicada automaticamente.

## Testes

- 62 testes automatizados aprovados.
- Compilação dos módulos alterados: OK.

Versão: 17.5.0
