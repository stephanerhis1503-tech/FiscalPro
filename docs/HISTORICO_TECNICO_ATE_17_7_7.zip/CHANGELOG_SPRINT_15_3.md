# FiscalPro — Sprint 15.3

## Identidade visual completa

- Criado o logotipo oficial do FiscalPro nas versões clara e para fundo escuro.
- Criado o monograma `FP` em múltiplos tamanhos para telas, atalhos e instalador.
- Criado o ícone oficial do Windows em formato `.ico` com múltiplas resoluções.
- Aplicado o ícone às telas de login, principal, recuperação, alteração de senha e Sobre.
- Substituído o selo textual do cabeçalho pelo símbolo oficial, com fallback seguro.
- Criada a janela **Sobre o FiscalPro** no menu do usuário.
- Incluídos versão, descrição, aviso de uso e créditos oficiais:
  - Criação e direção do projeto: **Stephane Rhis**
  - Desenvolvimento em parceria com **ChatGPT**
- Centralizados os metadados do aplicativo em `src/core/app_info.py`.
- Preparado o carregamento de recursos para execução pelo código-fonte e para o futuro executável PyInstaller.
- Corrigida a repetição de um item informativo na tela de login.
- Mantidas as funcionalidades, o login e os dados já aprovados nas sprints anteriores.

## Segurança dos dados

A entrega não contém nem substitui bancos de dados, documentos, tokens do Gmail,
credenciais ou configurações pessoais.
