# FiscalPro — Sprint 17.0.0

## Motor ICMS por UF — primeira fase

- Criado o serviço `ICMSUFService` com cobertura inicial para Minas Gerais, Espírito Santo, Bahia, Rio de Janeiro e São Paulo.
- Preservado integralmente o motor detalhado de Minas Gerais já aprovado.
- Separadas as seguintes camadas na consulta: alíquota da operação, alíquota interna do destino, FCP/FECOEP/FECOP, ICMS-ST/CEST e benefícios.
- Incluída a regra interestadual de 7% e 12%, além da alíquota de 4% para mercadorias importadas, mantida como condicional quando depende de conteúdo de importação ou exceção legal.
- Instaladas referências estaduais conservadoras:
  - São Paulo: alíquota modal de 18% e FECOEP nas hipóteses objetivas reconhecidas;
  - Espírito Santo: alíquota modal de 17%, regra específica de 12% para veículos relacionados e 25% mais adicional para bebidas e fumo abrangidos;
  - Bahia: alíquota modal de 20,5% e identificação inicial do FECOP;
  - Rio de Janeiro: separação entre 20% de ICMS e 2% de FECP, total geral de 22%.
- Criada a tela **ICMS por UF**, acessível pela Consulta Tributária.
- Mantido o botão para abrir o motor detalhado de ICMS/MG.
- Integrado o novo motor à tela DIFAL/FCP: quando os campos manuais ficam vazios, o FiscalPro usa as referências oficiais das UFs cobertas.
- Para UFs fora de Minas Gerais, o FiscalPro pode mostrar o CEST como indício, mas nunca reaproveita a MVA mineira. A MVA permanece em branco até existir regra estadual própria.
- UFs ainda não cobertas retornam claramente **UF ainda não coberta**, sem inventar alíquota ou MVA.
- Atualizados aplicativo, executável e instalador para a versão 17.0.0.
- Adicionados 16 testes automatizados da Sprint e executados 17 testes de regressão das Sprints 16.8 e 16.9.

## Limites desta fase

- As alíquotas modais não substituem a análise de alíquotas específicas por produto.
- Benefícios, reduções de base, isenções, diferimentos e regimes especiais de ES, BA, RJ e SP ainda ficam marcados para revisão.
- A cobertura completa de MVA e responsabilidade de ICMS-ST por UF será ampliada nas próximas etapas.
