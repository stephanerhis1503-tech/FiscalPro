# FiscalPro — Sprint 15.2

## Login e senha

- Tela profissional de primeiro acesso.
- Tela de login integrada à identidade visual da Sprint 15.1.
- Criação do primeiro usuário administrador dentro do próprio sistema.
- Senhas armazenadas com PBKDF2-HMAC-SHA256, sal aleatório e sem texto puro.
- Banco de autenticação separado do banco fiscal.
- Bloqueio temporário após cinco tentativas incorretas.
- Opção de lembrar somente o nome do usuário, nunca a senha.
- Botão para mostrar ou ocultar a senha.
- Código de recuperação exibido uma única vez no cadastro.
- Redefinição de senha por código de recuperação.
- Alteração de senha pelo menu da conta.
- Logout com retorno para a tela de acesso.
- Nome e perfil do usuário exibidos no cabeçalho do FiscalPro.

## Segurança dos dados

O arquivo de autenticação é criado somente no primeiro uso em:

`dados/seguranca/fiscalpro_auth.db`

A sprint não contém nem substitui o `fiscalpro.db`, o banco do robô, documentos,
tokens do Gmail ou credenciais existentes.
