# Hotfix 17.7.6 — C175: alíquota por quantidade e cabeçalhos oficiais

## Problema reproduzido
Na importação do TXT no PGE, registros C175 estavam sendo rejeitados no campo
`ALIQ_PIS_QUANT`. Exemplo real observado:

`|C175|5405|3,75|0,25|01|0,68|0,6500||0,00442|0,00|...|`

O valor `0,00442` corresponde ao cálculo bruto `0,68 × 0,65 / 100`, mas foi
parar no campo `ALIQ_PIS_QUANT`. Esse campo é uma alíquota específica em reais
por unidade e só faz sentido junto de `QUANT_BC_PIS`. No caso acima a operação
já está preenchida na modalidade ad valorem (`VL_BC_PIS` + `ALIQ_PIS`).

A aba C175 ainda saía com cabeçalhos genéricos `CAMPO_02`, `CAMPO_03`, etc., o
que também dificultava distinguir `ALIQ_PIS`, `ALIQ_PIS_QUANT` e `VL_PIS`.

## Correções
- C175 agora possui os 18 nomes técnicos reais no Excel:
  `REG`, `CFOP`, `VL_OPR`, `VL_DESC`, `CST_PIS`, `VL_BC_PIS`, `ALIQ_PIS`,
  `QUANT_BC_PIS`, `ALIQ_PIS_QUANT`, `VL_PIS`, `CST_COFINS`, `VL_BC_COFINS`,
  `ALIQ_COFINS`, `QUANT_BC_COFINS`, `ALIQ_COFINS_QUANT`, `VL_COFINS`,
  `COD_CTA`, `INFO_COMPL`.
- No fluxo Excel → TXT, se `ALIQ_PIS_QUANT`/`ALIQ_COFINS_QUANT` estiver
  preenchida sem a respectiva `QUANT_BC`, enquanto a modalidade ad valorem
  estiver completa, o FiscalPro remove automaticamente apenas o campo órfão.
- Base, alíquota percentual e valor da contribuição digitados pela usuária são
  preservados nesse saneamento.
- A correção aparece na Conferência Excel como `Ajuste automático C175`.
- O Pré-PVA passou a detectar:
  - `ALIQ_*_QUANT` sem `QUANT_BC_*`;
  - `QUANT_BC_*` sem `ALIQ_*_QUANT`;
  - preenchimento simultâneo das duas modalidades de cálculo.
- Quando não existe modalidade ad valorem completa, o FiscalPro não apaga uma
  alíquota por quantidade órfã automaticamente; apenas avisa para revisão.

## Validação
O caso real do PGE com `ALIQ_PIS_QUANT = 0,00442` foi reproduzido. Após o
saneamento a linha passa a ser:

`|C175|5405|3,75|0,25|01|0,68|0,6500|||0,00|01|0,68|3,0000|||0,02|||`

O erro local de modalidade C175 deixa de existir após a correção.

## Testes
147 testes automatizados aprovados.
