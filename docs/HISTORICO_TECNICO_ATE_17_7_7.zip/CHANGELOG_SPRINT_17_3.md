# FiscalPro — Sprint 17.3.0

## Correção Tributária Assistida em Lote

- Nova tela de propostas com seleção item a item e comparação antes/depois.
- Correção somente de divergências com confirmação específica do tributo.
- Suporte inicial a CST, base, alíquota e valores de PIS/Cofins no C170.
- Retotalização de PIS/Cofins no C100 em EFD Contribuições.
- Correção da alíquota ICMS no C170 apenas quando confirmada pelo motor estadual.
- Correção do CEST no 0200 quando o enquadramento de ICMS-ST estiver confirmado.
- Cópia segura por arquivo, sem alteração do SPED original.
- Bloqueio quando a linha mudou depois da análise.
- Pré-Validador executado na cópia corrigida.
- Relatório TXT individual e Excel consolidado com rastreabilidade e hashes SHA-256.
- XMLs e membros de ZIP permanecem somente para leitura.
- Aviso obrigatório para recalcular o Bloco M no PVA após mudanças de PIS/Cofins.
- Versão atualizada para 17.3.0.
