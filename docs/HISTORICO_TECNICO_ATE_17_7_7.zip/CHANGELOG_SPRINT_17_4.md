# FiscalPro — Sprint 17.4.0 — DIFAL Automático no SPED Fiscal

## Entrega

- Nova aba **DIFAL automático** dentro do SPED Inteligente.
- Novo comando **⚡ Auditar DIFAL automático**.
- Auditoria exclusiva da EFD ICMS/IPI (SPED Fiscal), sem alterar o arquivo.
- Leitura do registro **C101** vinculado ao C100.
- Reuso dos XMLs de NF-e já importados na Auditoria Tributária.
- O importador de NF-e passa a capturar:
  - `idDest`;
  - `indFinal`;
  - `indIEDest`;
  - UF de origem/destino;
  - grupo `ICMSUFDest` por item;
  - base, alíquota interna, interestadual, partilha, FCP, DIFAL destino e parcela remetente.
- Quando o XML confirma `idDest=2`, `indFinal=1` e `indIEDest=9`, o FiscalPro:
  - confirma a operação interestadual para consumidor final não contribuinte;
  - soma os valores do grupo ICMSUFDest;
  - compara DIFAL/FCP do XML com `VL_ICMS_UF_DEST` e `VL_FCP_UF_DEST` do C101;
  - aponta C101 ausente ou divergente.
- Sem XML, CFOP 6107/6108 é tratado apenas como **candidato para revisão**. O FiscalPro não presume DIFAL devido.
- Relatório TXT rastreável com NF, chave, UF, CFOP, evidência, base, alíquotas, DIFAL/FCP SPED x XML e orientação.

## Segurança

- Nenhuma correção é aplicada automaticamente nesta sprint.
- XML autorizado é usado como evidência documental para conferir o SPED; regras/benefícios da UF continuam sujeitas a revisão.
- Operação para consumidor final contribuinte (`indIEDest=1`) é separada e encaminhada para revisão, pois o C101 é direcionado ao consumidor final não contribuinte.
- IE isenta (`indIEDest=2`) não é classificada automaticamente como contribuinte ou não contribuinte.

## Testes

- 6 testes novos do motor DIFAL.
- Regressão completa do projeto preservada.
