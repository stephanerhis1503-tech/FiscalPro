# Sprint 16.3 — Correção encadeada de PIS/COFINS no SPED Contribuições

- Alíquotas de PIS e COFINS confirmadas na Correção Tributária passam a acionar recálculo dependente.
- O `VL_PIS` e o `VL_COFINS` do `C170` são recalculados pela base × alíquota ÷ 100, com arredondamento em duas casas.
- Operações por quantidade usam `QUANT_BC` × `ALIQ_QUANT` quando a base ad valorem não está informada.
- Os totais `VL_PIS` e `VL_COFINS` do `C100` pai são refeitos pela soma dos itens `C170`.
- O relatório separa correções confirmadas, recálculos automáticos, documentos retotalizados e avisos.
- O Bloco M não é alterado por aproximação; a tela e o relatório exigem regeneração/validação da apuração no PVA oficial quando houver recálculo documental.
- O arquivo original continua preservado e a cópia é gravada sem BOM em UTF-8 quando aplicável.
- Adicionado `tests/test_recalculador_piscofins.py` com testes de cálculo ad valorem, quantidade, ausência de base, tipo de SPED e integração com a Correção Tributária.

