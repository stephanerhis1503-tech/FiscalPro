# FiscalPro — Sprint 16.8.0

## Motor Nacional Seguro de DIFAL e FCP

- Cria o novo serviço `DIFALFCPNacionalService`.
- Valida se a operação é interestadual e destinada a consumidor final antes de indicar DIFAL.
- Identifica o responsável pelo recolhimento:
  - destinatário, quando contribuinte do ICMS;
  - remetente/prestador, quando o destinatário não é contribuinte.
- Calcula a alíquota interestadual de 4%, 7% ou 12%, preservando como condicional os casos de importação que exigem comprovação.
- Para destino em Minas Gerais, usa o Motor ICMS/MG para obter a alíquota interna específica ou residual.
- Para outras UFs, a tabela local existente é utilizada somente como referência condicional até confirmação do usuário.
- Permite informar e confirmar manualmente a alíquota interna e o FCP da UF de destino.
- Gera memória de cálculo nas modalidades:
  - base única por dentro;
  - base dupla por dentro;
  - por fora.
- Separa base de origem, base de destino, ICMS de origem, ICMS de destino, DIFAL e FCP.
- Adiciona a nova tela **DIFAL/FCP** à Consulta Tributária.
- Adiciona o botão **Calcular DIFAL/FCP** ao Motor ICMS/MG.
- Atualiza a versão central do FiscalPro para **16.8.0**.

## Segurança

- Não calcula DIFAL em operação interna.
- Não aplica DIFAL quando o destinatário não foi informado como consumidor final.
- Não confirma o resultado sem saber se o destinatário é contribuinte.
- Não trata alíquota geral de outra UF como regra definitiva.
- Simples Nacional e MEI permanecem com alerta para revisão específica.
- Benefícios, reduções de base e regras especiais da UF de destino não são presumidos.

## Testes

- 10 testes novos da Sprint 16.8 aprovados.
- 22 testes de regressão das Sprints 16.6, 16.7 e Hotfix 16.5.1 aprovados.
