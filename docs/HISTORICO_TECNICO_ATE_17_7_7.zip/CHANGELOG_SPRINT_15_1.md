# FiscalPro — Sprint 15.1

## Redesign Visual

- Nova identidade visual clara, profissional e consistente.
- Cabeçalho com marca FiscalPro, status do sistema e versão da interface.
- Navegação principal padronizada em cinco áreas: SPED, Tributação, Correções, Relatórios e Robô Fiscal.
- Dashboard SPED com cards responsivos e destaques visuais.
- Ações principais organizadas e sempre visíveis.
- Área de Tributação simplificada em três caminhos: Ficha Inteligente, Simulador e ICMS-ST por XML.
- Rodapé de status com créditos do projeto.
- Tema ttk aplicado às janelas e componentes existentes, sem dependências externas.
- Robô Fiscal colocado em área rolável para evitar botões escondidos em telas menores.
- Central de Relatórios preparada visualmente para integrações futuras.

## Segurança

- Nenhum banco de dados foi alterado.
- Nenhuma regra tributária, rotina do SPED ou automação do Robô Fiscal foi modificada.
- A entrega contém somente arquivos de interface, documentação e teste.
