# FiscalPro — Sprint 17.4.1

## Excel → SPED com Pré-PVA comparativo

- Mantém toda a validação reversível já existente do Excel → TXT.
- Reconstrói o futuro TXT em memória antes de gravar o arquivo.
- Executa o Pré-Validador PVA no SPED original e no reconstruído.
- Compara causas por assinatura estável, sem depender do número da linha.
- Erros que já existiam no arquivo original não bloqueiam a conversão por si só.
- Somente novas pendências criadas pela edição da planilha bloqueiam a geração.
- Novos avisos são mostrados na aba Excel → TXT.
- O relatório Excel → TXT passa a registrar erros/avisos antes e depois.
- A validação oficial no PVA continua obrigatória.

Versão: 17.4.1
