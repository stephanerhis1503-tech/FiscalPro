# Hotfix 17.6.8 — Múltiplos M100/M500 no Excel → TXT

## Problema identificado
No fluxo Excel → SPED TXT, o sincronizador do Bloco M procurava primeiro um único M100/M500 pela alíquota. Em arquivos com mais de um grupo legítimo usando a mesma alíquota — por exemplo, dois M100 a 1,6500% para origens documentais diferentes — a validação era bloqueada antes de usar o vínculo já existente nos M105/M505.

Mensagem típica:
`não foi possível identificar um único M100 para alíquota 1,6500 (PIS)`.

## Correção
- A alíquota deixa de ser usada como identificador único do M100/M500.
- O FiscalPro reúne os M105/M505 de todos os pais candidatos da mesma alíquota e CST.
- O filho correspondente aos C170 é identificado, em ordem conservadora, por:
  1. base de crédito compatível;
  2. composição por origem documental (A170, C170 e D101/D105);
  3. NAT_BC_CRED já comprovada por outra alíquota do mesmo crédito.
- Somente depois de identificar o M105/M505 o FiscalPro infere qual M100/M500 é o pai correto pela hierarquia do arquivo.
- Apenas o pai efetivamente ligado aos C170 alterados é recalculado; outros grupos com a mesma alíquota permanecem intocados.

## Segurança
- Nenhuma NAT_BC_CRED é criada ou adivinhada.
- Grupos de crédito diferentes não são unidos só porque usam a mesma alíquota.
- Se dois filhos continuarem indistinguíveis, o FiscalPro mantém o bloqueio para revisão em vez de escolher um deles no chute.

## Validação técnica
- 3 testes novos específicos do Hotfix 17.6.8 aprovados.
- Bateria completa do projeto: **122 testes aprovados**.
- Compilação do módulo alterado: OK.
