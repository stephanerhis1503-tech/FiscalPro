# FiscalPro — Sprint 15.7.2

## Consolidação de duplicidades no Excel → SPED TXT

- identifica C190 duplicados dentro da mesma NF-e;
- identifica D190 duplicados dentro do mesmo CT-e;
- considera a chave tributária CST + CFOP + alíquota + código de observação;
- soma automaticamente os valores fiscais dos registros equivalentes;
- mantém somente um registro consolidado;
- recalcula C990, D990, 9900, 9990, 9999 e demais fechamentos existentes;
- mostra no resultado da validação quantos grupos foram consolidados e quantas linhas foram removidas;
- registra cada consolidação no relatório TXT;
- detecta itens C170 idênticos e gera aviso, sem apagar automaticamente itens reais da nota;
- preserva a correção de gravação do SPED sem BOM da Sprint 15.7.1.

A consolidação automática fica restrita aos registros analíticos C190 e D190, pois itens C170 iguais podem representar linhas legítimas do documento fiscal.
