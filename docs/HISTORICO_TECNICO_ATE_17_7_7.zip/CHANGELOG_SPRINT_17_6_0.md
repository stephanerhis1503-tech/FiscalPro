# FiscalPro — Sprint 17.6.0
## Controle de Entregas e Arquivos

Base: Sprint 17.5.2 aprovada.

### Objetivo
Criar um controle operacional mensal de entrega de arquivos por empresa, sem interferir nos módulos tributários, SPED, Robô Fiscal ou Contas a Pagar.

### Entregue
- Nova aba **Controle de Entregas** na janela principal.
- Cadastro independente de empresas do controle.
- Cadastro de **modelos mensais** por empresa.
- Geração automática do checklist de uma competência a partir dos modelos.
- Controle por:
  - empresa;
  - competência;
  - arquivo/obrigação;
  - prazo;
  - data de entrega;
  - status;
  - destinatário;
  - arquivo vinculado;
  - observações.
- Status automáticos:
  - PENDENTE;
  - ENTREGUE;
  - ATRASADO;
  - NÃO SE APLICA.
- Cards de resumo por filtro: Total, Entregues, Pendentes, Atrasados e Não se aplica.
- Filtros por empresa, competência, status e busca livre.
- Ações rápidas: nova entrega, editar, marcar entregue, reabrir, não se aplica, abrir arquivo e excluir.
- Exportação de relatório CSV respeitando os filtros da tela.
- Banco próprio `dados/entregas/controle_entregas.db`, mantendo os dados isolados dos bancos fiscais.
- Geração de competência idempotente: itens já existentes não são duplicados.
- Prazo mensal com ajuste automático para o último dia do mês quando o modelo usa dia 29, 30 ou 31 em mês menor.

### Segurança
- Nenhuma alteração nos motores tributários aprovados na Sprint 17.5.2.
- Nenhuma alteração em SPED, correção assistida ou Excel → SPED.
- O módulo não envia arquivos automaticamente nesta sprint; apenas controla e registra as entregas.

### Testes
- 88 testes automatizados aprovados no projeto completo.
- Compilação Python dos módulos: OK.
