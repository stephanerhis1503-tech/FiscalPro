# FiscalPro - Sprint 17.1.0

## ICMS-ST detalhado por UF - Autopecas

- Criado o servico `ICMSSTUFService` para regras estaduais rastreaveis de autopecas em SP, ES, BA e RJ.
- Mantido integralmente o motor detalhado de Minas Gerais.
- O resultado agora separa:
  - sujeicao ao ICMS-ST na UF e no periodo;
  - confirmacao da decisao estadual;
  - CEST e descricao legal;
  - MVA original, MVA ajustada e MVA efetivamente aplicada;
  - contrato de fidelidade;
  - vigencia inicial e final;
  - responsabilidade pelo recolhimento e situacao do acordo interestadual;
  - fundamento e fonte oficial.
- Adicionada a opcao **Contrato de fidelidade** na tela ICMS por UF.
- Sao Paulo:
  - IVA-ST original de 47,19% para fidelidade e 72,15% nos demais casos, ate 30/09/2026;
  - calculo automatico do IVA-ST ajustado em entrada interestadual;
  - exclusao confirmada da ST de autopecas a partir de 01/10/2026, conforme Portaria SRE 34/2026.
- Bahia:
  - regras do Anexo 1 do RICMS/BA, redacao vigente em 2026;
  - MVA original de 36,56% ou 71,78%;
  - tabelas ajustadas de 4%, 7% e 12%.
- Espirito Santo:
  - regras do Anexo V do RICMS/ES;
  - MVA original de 36,56% ou 71,78%;
  - tabelas ajustadas conforme origem e aliquota interestadual.
- Rio de Janeiro:
  - regras do item 7 do Anexo I do Livro II do RICMS/RJ;
  - MVA original de 36,56% ou 71,78%;
  - MVA ajustada de 50,22%/88,96% para 12% e 63,87%/106,14% para 4%.
- Produtos sem CEST ou fora do segmento detalhado continuam sem MVA inventada.
- Atualizados aplicativo, executavel e instalador para a versao 17.1.0.
- Adicionados 16 testes novos e atualizada a regressao da Sprint 17.0.

## Limites desta fase

- A cobertura estadual detalhada desta Sprint e inicialmente para o segmento de autopecas.
- Beneficios, reducoes, isencoes, diferimentos, regimes especiais e excecoes por contribuinte continuam marcados para revisao.
- A responsabilidade interestadual pode depender do protocolo vigente e da condicao concreta de remetente e destinatario.
