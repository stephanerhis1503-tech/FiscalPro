# FiscalPro — Hotfix 17.3.14

## ICMS Fiscal → PIS/COFINS sem depender da ordem das correções

Correção do bloqueio que ainda podia exibir:

> O M105 correspondente aos C170 de alíquota 1.6500 / CST 50 não pôde ser identificado com segurança.

### Ajustes
- O botão ICMS Fiscal → PIS/COFINS agora funciona mesmo quando o arquivo aberto ainda possui M100/M500 duplicados de uma etapa anterior.
- Antes da reapuração, o FiscalPro consolida apenas os grupos que o consolidador seguro da 17.3.9 já comprova matematicamente.
- M105/M505 podem ser identificados por base, origem documental e NAT_BC_CRED comprovada em outra alíquota do mesmo crédito.
- Pendências já existentes antes do clique não bloqueiam mais esta rotina; qualquer erro novo introduzido pela exclusão do ICMS continua bloqueando a geração.
- Se a consolidação alterar a estrutura, M990/9900/9990/9999 são recontados.
- Arquivos antigos sem M600/M610 podem ter a COFINS criada pela mesma regra conservadora já aprovada na 17.3.8, antes da atualização do M200.

### Segurança
Nenhuma NAT_BC_CRED é inventada e nenhum M105/M505 é escolhido por aproximação livre. Ajustes, diferimentos, saldos ou vínculos realmente ambíguos continuam bloqueados.
