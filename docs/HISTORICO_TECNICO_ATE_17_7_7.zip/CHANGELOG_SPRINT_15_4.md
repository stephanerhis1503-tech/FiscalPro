# Sprint 15.4 — Executável e instalador profissional

## Entregas

- Configuração PyInstaller em modo `onedir`, sem janela de console.
- Metadados de versão e ícone incorporados ao `FiscalPro.exe`.
- Instalador Inno Setup em português, por usuário e sem privilégio administrativo.
- Atalhos no Menu Iniciar e Área de Trabalho.
- Desinstalador integrado ao Windows.
- Gerador automático `CRIAR_INSTALADOR.bat`.
- Estrutura persistente em `%LOCALAPPDATA%\FiscalPro` no aplicativo empacotado.
- Migração não destrutiva dos dados da instalação antiga em `C:\FiscalPro`.
- Templates iniciais sem dados pessoais, credenciais ou históricos do usuário.
- Arquivo de dependências do Robô Fiscal restaurado.

## Segurança dos dados

O pacote não inclui bancos de autenticação, token do Gmail, configurações do
Robô Fiscal, documentos ou históricos pessoais. Bases oficiais públicas foram
mantidas apenas no template fiscal inicial.
