# CHANGELOG — Sprint 15.10

- Novo fluxo **Gerar final + estorno** na aba Correção assistida.
- Correções assistidas e estorno de ICMS passam a gerar um único TXT final.
- Estorno reanalisado sobre as linhas já corrigidas.
- Arquivos intermediários descartados automaticamente.
- Relatório final unificado com correções, estorno e resultado da pré-validação.
- Saída UTF-8 sem BOM para evitar erro do registro 0000 no PVA.
- Mantidas as funções DANFE/PDF × SPED da Sprint 15.9.
- Versão atualizada para 15.10.
