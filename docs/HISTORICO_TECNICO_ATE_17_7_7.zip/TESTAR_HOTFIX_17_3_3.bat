@echo off
cd /d "%~dp0"
python TESTE_HOTFIX_17_3_3.py
if errorlevel 1 (
  echo.
  echo FALHA no teste do Hotfix 17.3.3.
  pause
  exit /b 1
)
echo.
echo Hotfix 17.3.3 aprovado.
pause
