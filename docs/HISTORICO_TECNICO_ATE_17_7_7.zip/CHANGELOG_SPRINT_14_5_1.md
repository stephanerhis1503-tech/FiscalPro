# FiscalPro — Sprint 14.5.1

## Correção

- Incluída a sincronização do segmento 16 do Anexo VII do RICMS/MG: pneumáticos, câmaras de ar e protetores de borracha.
- Corrigida a consulta do NCM `40114000` — pneus novos para motocicletas.
- Enquadramento oficial: CEST `16.003.00`, âmbito `16.1` e MVA original `60%`.
- A consulta de ICMS-ST/MG agora pesquisa todos os segmentos oficiais já sincronizados, priorizando o NCM mais específico.
- A persistência foi ajustada para atualizar cada segmento separadamente, sem apagar os registros dos demais segmentos.
- Textos da Ficha Inteligente foram generalizados para não indicar incorretamente que a consulta abrange somente autopeças.

## Segurança

- Nenhum banco de dados acompanha a entrega.
- Operações interestaduais continuam exigindo conferência do âmbito, responsabilidade, exceções e condições da operação real.
