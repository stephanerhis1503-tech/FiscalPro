# FiscalPro — Sprint 17.4.2

## Conferência de Alterações Excel → SPED

- Novo botão **🔎 Conferir alterações** após a validação da planilha.
- Nova aba **Conferência Excel** com comparação **Original × Novo**.
- Exibição de:
  - tipo da mudança: Alteração, Inclusão ou Exclusão;
  - categoria: Identificação, Tributário, Valor, Cadastral ou Outro;
  - registro;
  - sequência;
  - aba e linha do Excel;
  - campo alterado;
  - valor original;
  - novo valor.
- Filtros por registro, tipo, categoria e busca livre.
- Contador de alterações exibidas e total detectado.
- Novo botão **💾 Gerar relatório** da conferência antes da geração do TXT.
- Inclusões não vinculadas continuam bloqueadas pela segurança do Excel → TXT, mas passam a aparecer na conferência.
- Exclusões seguras de registros condicionais 0205/0220 passam a aparecer como exclusões na conferência.

## Segurança preservada

- A conferência é somente informativa; nenhuma alteração é aplicada automaticamente.
- O Excel original permanece intacto.
- O Pré-PVA comparativo da Sprint 17.4.1 continua ativo.
- Erros que já existiam no SPED original não bloqueiam por si só.
- Somente novos erros criados pela edição da planilha bloqueiam a geração do TXT.
- O PVA/PGE oficial continua sendo a validação final antes da transmissão.

## Testes

- 53 testes automatizados aprovados.
- Compilação dos módulos alterados: OK.
- Teste integrado real da rotina:
  - descrição do registro 0200 alterada;
  - 1 alteração detectada;
  - categoria Cadastral;
  - 0 novos erros no Pré-PVA;
  - relatório de conferência gerado;
  - TXT gerado normalmente com a alteração aplicada.

Versão: 17.4.2
