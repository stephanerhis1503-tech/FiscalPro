# FiscalPro — Hotfix 17.6.9

## Crédito C170 sem M100/M500 correspondente no Bloco M

### Problema identificado
No fluxo Excel → SPED TXT, depois do Hotfix 17.6.8 o FiscalPro passou a distinguir corretamente vários M100/M500 na mesma alíquota. Em um segundo cenário real, a mensagem passou a ser mais específica:

> não há M100 para alíquota 1,6500 (PIS)

O caso ocorre quando o Excel **reduz** uma base de crédito existente nos C170, mas o SPED original já não possuía um M100/M500 correspondente àquela alíquota. A rotina antiga tratava a ausência do pai como bloqueio, mesmo não existindo crédito apurado no Bloco M a reduzir.

### Correção
- Quando o delta do Excel **reduz crédito** e o SPED original também não possuía M100/M500 para aquela alíquota, o FiscalPro não cria um pai artificial e não bloqueia a planilha.
- A redução documental dos C170 é preservada e o caso é informado como aviso para confirmação no Pré-PVA/PGE.
- Se o M100/M500 existia no SPED original e desapareceu durante a reconstrução, o bloqueio permanece por segurança.
- Se a alteração **aumenta crédito** e não existe M100/M500 correspondente, o bloqueio permanece: o FiscalPro não cria grupo novo de crédito sem apuração original que comprove o vínculo.
- A consolidação M200/M600 só é recalculada quando algum M100/M500 foi efetivamente alterado.

### Segurança
O hotfix não inventa COD_CRED, NAT_BC_CRED, rateio ou novo grupo de crédito. Ele apenas deixa de exigir um M100/M500 inexistente quando o Excel está retirando crédito que já não era apropriado no Bloco M original.

### Validação técnica
- 3 testes novos específicos do cenário M100 ausente.
- Testes do Hotfix 17.6.8 mantidos.
- Bateria completa do projeto: **125 testes aprovados**.
- Revalidação do arquivo real anterior com 4.229 alterações: **0 erros** e 82 ajustes automáticos no Bloco M, sem regressão.
