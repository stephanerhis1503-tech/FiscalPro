# FiscalPro — Hotfix 17.3.16

## Base de aquisição + anti-dupla exclusão de ICMS

- Corrige a rotina ICMS Fiscal → PIS/COFINS para reconhecer quando o próprio SPED Fiscal já traz a base de crédito líquida do ICMS.
- Usa a VL_BC_ICMS do item como referência da base bruta comprovada da aquisição e exclui o ICMS próprio uma única vez.
- Preserva frete/seguro rateado quando já compõe a base de aquisição.
- Bloqueia casos em que a base do SPED Fiscal não coincide nem com a forma bruta nem com a forma líquida esperada.
- Mantém o recálculo de C170, C100 e Bloco M.

### Teste real — Mega Mix 07/2026
- 170 itens com ICMS próprio na fonte fiscal.
- 88 itens já estavam líquidos de ICMS e foram preservados.
- 82 itens ainda estavam brutos e foram corrigidos.
- ICMS efetivamente excluído nesta etapa: R$ 29.771,42.
- Redução efetiva de PIS: R$ 491,25.
- Redução efetiva de COFINS: R$ 2.262,59.
- Pré-Validador local: 0 erros / 0 avisos.
- Testes automatizados: 41 aprovados.
