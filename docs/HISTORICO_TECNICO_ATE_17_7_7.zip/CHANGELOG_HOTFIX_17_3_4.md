# FiscalPro - Hotfix 17.3.4 - Espelho do PGE

Data: 07/08/2026

## Referência de teste

Relatório real do PGE EFD-Contribuições 6.1.2 da MEGA MIX E-COMMERCE LTDA,
competência 07/2026, com 277 erros de validação.

## O que foi acrescentado ao Pré-Validador

- CST de PIS/COFINS incompatível com operação de entrada/aquisição.
- Alíquota básica zerada com CST 01, considerando o IND_INC_TRIB do 0110.
- CFOP 1929 rejeitado pelo PGE (somente aponta; não troca automaticamente).
- Duplicidade de COD_ITEM no 0200, apontando todas as ocorrências.
- Duplicidade da chave de crédito nos M100/M500.
- Indício de duplicação de base não cumulativa nos M105/M505 quando decorre de pais duplicados.
- COD_CTA ausente nos M400/M800.
- M410/M810 obrigatório ausente.
- Vigência 0205 fora da competência e períodos 0205 sobrepostos.
- Divergência entre bases de PIS e COFINS no C175.
- A001/D001 com IND_MOV=0 sem registros operacionais no bloco.

## Correções automáticas seguras

O botão "Gerar SPED corrigido" passa a aplicar somente os casos determinísticos:

1. CST 01 com alíquota básica zerada:
   - IND_INC_TRIB=1: PIS 1,6500 e COFINS 7,6000.
   - IND_INC_TRIB=2: PIS 0,6500 e COFINS 3,0000.
2. C170 de entrada/aquisição (CFOP iniciado por 1, 2 ou 3) com CST 08:
   - CST_PIS 08 -> 74.
   - CST_COFINS 08 -> 74.
3. Dependências da alíquota corrigida no C170:
   - recalcula VL_PIS/VL_COFINS pela base e alíquota do próprio registro;
   - retotaliza VL_PIS/VL_COFINS do C100 pai;
   - mantém o Bloco M como pendência explícita de re-apuração no PGE oficial.

## Pendências que permanecem assistidas/manuais

- CFOP rejeitado pelo PGE, quando não é possível inferir o CFOP correto.
- COD_ITEM duplicado no 0200.
- Consolidação de M100/M500 duplicados.
- Consolidação/recomposição de M105/M505.
- Conta contábil COD_CTA e cadastro 0500.
- NAT_REC necessária para criar M410/M810.

O FiscalPro não inventa conta contábil, CFOP, natureza de receita ou base de crédito.

## Observação sobre a contagem

O PGE pode repetir a mesma causa em mais de uma regra de validação. O FiscalPro
consolida a pendência por campo/linha, portanto o total exibido pelo FiscalPro
pode ser menor que o total do PGE mesmo quando todas as causas estão mapeadas.

## Testes

- 8 testes automatizados aprovados.
- Regressão das regras anteriores preservada.
