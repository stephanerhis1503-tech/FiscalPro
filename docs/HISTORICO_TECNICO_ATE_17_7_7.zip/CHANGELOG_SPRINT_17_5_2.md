# FiscalPro — Sprint 17.5.2

## Decisão Tributária da Operação

Base: Hotfix 17.5.1 aprovado.

### Evolução principal

O Robô Tributário passa a transformar o diagnóstico dos motores em uma decisão operacional assistiva, sem aplicar correções automaticamente.

A nova camada mostra:

- CFOP provável com status de segurança;
- CST/CSOSN de ICMS quando o contexto permite confirmação;
- CST de PIS e COFINS aproveitando a conclusão do motor nacional;
- indicação de destaque ou não do ICMS;
- situação operacional do ICMS-ST;
- necessidade de DIFAL/FCP e responsável quando o motor consegue concluir;
- alertas quando faltam informações ou quando ST e DIFAL precisam de revisão conjunta.

### CFOPs tratados de forma determinística nesta sprint

Para venda/saída comum, quando o perfil e a situação tributária permitem concluir:

- 5101 — venda interna de produção do estabelecimento;
- 5102 — venda interna de mercadoria adquirida/recebida de terceiros;
- 5401 — produção própria com ST, contribuinte substituto;
- 5403 — mercadoria de terceiros com ST, contribuinte substituto;
- 5405 — mercadoria de terceiros com ST já retido, contribuinte substituído;
- 6101/6102 — venda interestadual para contribuinte;
- 6107/6108 — venda interestadual destinada a não contribuinte;
- 6401/6403 — venda interestadual com retenção de ST pelo substituto;
- 6404 — venda interestadual com imposto já retido anteriormente.

Devolução, transferência, remessa e outros cenários continuam em REVISAR até terem uma regra específica.

### Novo contexto na interface

- Destinatário ICMS: contribuinte / não contribuinte / não informado;
- Mercadoria importada;
- Exceção à alíquota interestadual de 4%;
- painel "Decisão da operação" com CFOP, ICMS, destaque, PIS, COFINS e DIFAL/FCP.

### Segurança

- A ausência de dado nunca vira conclusão automática de ausência de tributação.
- Venda interestadual sem informar a condição de contribuinte do destinatário não recebe CFOP definitivo quando essa informação altera a classificação.
- Operação interestadual para consumidor final que também envolva ICMS-ST permanece em revisão conjunta para DIFAL/ST.
- Simples Nacional não recebe CSOSN definitivo quando a permissão de crédito/isenção não pode ser deduzida do contexto.
- Mercadoria marcada como importada não recebe automaticamente origem 0 no CST; o robô mantém `x00`, `x10` ou `x60` em REVISAR até a origem ser definida.
- O robô continua consultivo: não altera cadastro, SPED ou NF-e.

### Testes

- 80 testes automatizados aprovados.
- Teste integrado real com NCM 40114000, MG → MG, Lucro Real, comerciante e ICMS-ST já retido:
  - CFOP 5405 confirmado;
  - CST 060 confirmado;
  - sem destaque de ICMS;
  - PIS CST 04 e COFINS CST 04 confirmados;
  - DIFAL não aplicável por ser operação interna;
  - Reforma 2026 preservada como REVISAR.
