# FiscalPro — Sprint 17.6.2

## Agenda de Entregas por Vencimento

Esta sprint evolui o Controle de Entregas sem alterar os módulos SPED, Robô Tributário ou Contas a Pagar.

### Novidades

- Novo filtro **Mês/Data do prazo** independente da competência.
- Opções: **Hoje**, **Próximos 7 dias**, **Este mês**, **Próximo mês** e **Todos**.
- A tela abre por padrão em **Competência = Todas** e **Prazo = Este mês**, permitindo enxergar, por exemplo, a competência 07/2026 que vence em 08/2026.
- Cards de Total, Entregues, Pendentes, Atrasados e Não se aplica passam a respeitar o período real do prazo.
- Relatório CSV respeita também o filtro de vencimento selecionado.
- Ordenação operacional: atrasados e pendentes aparecem primeiro, organizados pela data real do prazo.

### Segurança

- Nenhum dado existente é migrado ou apagado.
- A lógica aprovada do Hotfix 17.6.1 para competência × prazo permanece intacta.
- Entregas concluídas e itens “Não se aplica” continuam preservados.
