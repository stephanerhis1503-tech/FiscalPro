# FiscalPro — Sprint 17.7.0
## Auditoria de Cadastros por XML de Saída

### Objetivo
Transformar os XMLs de saída em uma auditoria preventiva do cadastro tributário do ERP, agrupando as ocorrências por código de produto em vez de listar nota por nota.

### Entregas
- nova tela **Inteligência tributária → Auditoria de cadastros por XML**;
- leitura de pasta, XMLs avulsos e ZIPs usando o motor de análise tributária em lote já aprovado;
- consideração apenas de itens de saída (CFOP iniciado por 5, 6 ou 7); itens de entrada são ignorados na consolidação;
- agrupamento por `cProd`; quando o código estiver ausente, usa NCM + descrição normalizada como chave auxiliar;
- classificação do cadastro em **CORRIGIR**, **REVISAR** ou **OK**;
- `CORRIGIR` somente quando existe divergência tributária confirmada pelo motor;
- detecção do mesmo produto com tratamentos diferentes em operações equivalentes;
- consolidação de CFOP, CST ICMS, PIS, COFINS e CEST observados nos XMLs;
- sugestão de PIS/COFINS, alíquota de ICMS e CEST somente quando o motor possui valor esperado;
- detalhes com divergências, pendências, segurança e exemplos de NF-e;
- filtros por status, inconsistências e busca por código/descrição/NCM;
- exportação Excel com abas **Cadastros para revisar**, **Resumo** e **Ocorrências**;
- nenhuma alteração automática em XML, ERP, SPED ou banco tributário.

### Regra de segurança
O XML comprova como a NF-e foi emitida, mas não comprova sozinho como o cadastro do ERP está configurado. Por isso o FiscalPro aponta o cadastro/regra a revisar e só usa `CORRIGIR` para divergências que o motor conseguiu confirmar.

### Validação técnica
- 6 testes novos da Sprint 17.7.0 aprovados;
- bateria completa do projeto: **119 testes aprovados**;
- compilação dos módulos alterados: OK.
