from __future__ import annotations

import sys
from pathlib import Path

from src.sped.pre_validador import PreValidadorPVA


def _linha(*campos: str) -> str:
    return "|" + "|".join(campos) + "|"


def teste_regras_novas() -> None:
    linhas = [
        _linha("0000", "006", "0", "", "", "01052026", "31052026", "EMPRESA TESTE", "12345678000199", "MG", "3106200", "", "00", "2"),
        _linha("0001", "0"),
        _linha("0190", "UN", "Unidade"),
        _linha("0200", "ITEM1", "PRODUTO TESTE", "", "", "UN", "00", "87141000", "", "", "", "0,00"),
        _linha("0205", "PRODUTO ANTIGO 1", "01012024", "10062026", ""),
        _linha("0205", "PRODUTO ANTIGO 2", "10062026", "15062026", ""),
        _linha("A001", "0"),
        _linha("A010", "12345678000199"),
        _linha("A990", "3"),
        _linha("C001", "0"),
        _linha("C010", "12345678000199", "2"),
        _linha("C100", "1", "0", "", "65", "00", "1", "1", "31260512345678000199650010000000011000000001", "02052026", "02052026", "10,00", "0", "0,00", "0,00", "10,00", "9", "0,00", "0,00", "0,00", "10,00", "1,80", "", "", "", "0,07", "0,25", "0,00", "0,00"),
        _linha("C175", "5102", "10,00", "0,00", "49", "1,80", "0,6500", "", "", "0,01", "49", "1,50", "3,0000", "", "", "0,05", "", ""),
        _linha("C990", "4"),
        _linha("D001", "0"),
        _linha("D010", "12345678000199"),
        _linha("D990", "3"),
        _linha("9001", "0"),
        _linha("9990", "2"),
        _linha("9999", "20"),
    ]

    resultado = PreValidadorPVA().validar(linhas, "EFD Contribuições")
    mensagens = [a.mensagem for a in resultado.erros]

    assert any("não é anterior ao fim da competência" in m for m in mensagens)
    assert any("Períodos do 0205 se sobrepõem" in m for m in mensagens)
    assert any("Bloco A está marcado com movimento" in m for m in mensagens)
    assert any("Bloco D está marcado com movimento" in m for m in mensagens)
    assert any("Bases divergentes no C175" in m for m in mensagens)


def teste_arquivo_real(caminho: Path) -> None:
    if not caminho.is_file():
        raise FileNotFoundError(caminho)
    texto = caminho.read_text(encoding="latin1", errors="replace")
    resultado = PreValidadorPVA().validar(texto.splitlines(), "EFD Contribuições")
    assert len(resultado.erros) == 16, (
        f"Esperados 16 erros no arquivo de regressão; encontrados {len(resultado.erros)}."
    )


if __name__ == "__main__":
    teste_regras_novas()
    if len(sys.argv) > 1:
        teste_arquivo_real(Path(sys.argv[1]))
        print("OK — regras novas + arquivo real: 16 pendências localizadas.")
    else:
        print("OK — regras novas do Hotfix 17.3.3 aprovadas.")
