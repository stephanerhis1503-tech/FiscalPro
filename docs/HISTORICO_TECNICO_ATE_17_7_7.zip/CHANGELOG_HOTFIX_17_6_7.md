# Hotfix 17.6.7 — Recuperação do Robô Fiscal Gmail

## Problema identificado
O Robô Fiscal podia aparentar ter parado porque a configuração histórica buscava, por padrão, somente mensagens `is:unread`. Se a mensagem fosse aberta no celular, Gmail web ou outro cliente antes da execução do FiscalPro, ela deixava de entrar na busca, apesar de nunca ter sido processada pelo robô.

Além disso, a consulta não limitava explicitamente a pesquisa à caixa de entrada, permitindo que mensagens enviadas também entrassem no universo de busca.

## Correções
- A busca padrão passa a considerar todas as mensagens recentes da caixa de entrada (`in:inbox`).
- O controle de duplicidade continua sendo feito pelo ID da mensagem no banco local do Robô Fiscal.
- Configurações antigas são migradas uma vez para desmarcar `Somente e-mails não lidos`.
- A opção de buscar somente não lidos continua disponível manualmente.
- A interface agora explica que o modo recomendado é deixar essa opção desmarcada.
- Mensagens em `Enviados` deixam de entrar na busca normal do robô.

## Segurança
Nenhuma mensagem é apagada, marcada como lida ou alterada pelo FiscalPro. A permissão Gmail permanece somente leitura.
