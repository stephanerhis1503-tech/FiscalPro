# Sprint 14.6 — Conferência do ICMS-ST da NF-e

## Implementado

- Leitura do ICMS-ST informado por item no XML (`vICMSST`).
- Leitura do total de ICMS-ST da NF-e (`vST`).
- Leitura separada de ST retido anteriormente (`vICMSSTRet`), sem tratá-lo como destaque da operação atual.
- Comparação por item entre o ICMS-ST calculado pelo FiscalPro e o ICMS-ST informado no XML.
- Diferença exibida como **calculado - XML**.
- Classificação automática:
  - CORRETO;
  - ST NÃO DESTACADO;
  - VALOR MENOR QUE O CALCULADO;
  - VALOR MAIOR QUE O CALCULADO;
  - ST RETIDO ANTERIORMENTE — REVISAR;
  - REVISAR NCM / CEST / MVA.
- Tolerância padrão de R$ 0,05 para diferenças de arredondamento.
- Novas colunas na tela e na planilha:
  - ICMS-ST calculado;
  - ICMS-ST no XML;
  - Diferença;
  - Conferência.
- Resumo da nota com totais do XML, calculado e diferença total.
- Identificação visual por cores na tela e na planilha.
- Preservada a coluna **Valor do item + IPI**.

## Segurança

O módulo faz uma conferência assistida. Resultado matematicamente coincidente não elimina a necessidade de conferir NCM, CEST, descrição, MVA, alíquotas, benefícios e responsabilidade pelo recolhimento.
