# FiscalPro — Hotfix 17.6.1

## Controle de Entregas — Competência × Prazo

### Correção principal
- A competência deixa de ser usada como mês do vencimento automaticamente.
- Cada modelo mensal agora possui o campo **Prazo após a competência**.
- Opções na interface:
  - Mesmo mês
  - Mês seguinte
  - 2 meses depois
- O padrão para modelos novos e modelos existentes passa a ser **Mês seguinte**.

### Exemplos
- Competência 07/2026 + dia 20 + Mês seguinte → prazo 20/08/2026.
- Competência 12/2026 + dia 10 + Mês seguinte → prazo 10/01/2027.
- Competência 12/2026 + dia 31 + 2 meses depois → prazo 28/02/2027.

### Migração segura
- O banco `controle_entregas.db` é atualizado automaticamente ao abrir o FiscalPro.
- Empresas e modelos já cadastrados são preservados.
- Nenhum banco de dados é incluído no hotfix.
- Modelos antigos recebem automaticamente `Mês seguinte`.

### Checklists já gerados
- Ao clicar novamente em **Gerar competência**, itens ainda `PENDENTE` ou `ATRASADO` e vinculados a um modelo têm o prazo recalculado.
- Itens `ENTREGUE` e `NÃO SE APLICA` não são alterados.
- Lançamentos manuais não vinculados a modelo não são alterados.

### Segurança
- Mantidas as regras, filtros, relatórios, anexos e histórico do Controle de Entregas.
- Mantidas as funcionalidades aprovadas do Robô Tributário 17.5.2.
- 94 testes automatizados aprovados no projeto completo.
